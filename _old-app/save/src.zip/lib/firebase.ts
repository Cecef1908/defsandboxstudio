import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, signInWithCustomToken, signInAnonymously } from "firebase/auth";

// --- GLOBAL VARIABLES ---
declare const __app_id: string;
declare const __firebase_config: string;
declare const __initial_auth_token: string | undefined; 

// Configuration
const firebaseConfig = JSON.parse(
  typeof __firebase_config !== 'undefined' ? __firebase_config : '{}'
);

// Fallback config (Votre projet)
if (Object.keys(firebaseConfig).length === 0) {
  firebaseConfig.apiKey = "AIzaSyDmxgS9RJbV0SPsNbtQvSg27Cx-MPAaOg8";
  firebaseConfig.authDomain = "sandbox-media-automation-27132.firebaseapp.com";
  firebaseConfig.projectId = "sandbox-media-automation-27132";
  firebaseConfig.storageBucket = "sandbox-media-automation-27132.appspot.com";
  firebaseConfig.messagingSenderId = "602482355230";
  firebaseConfig.appId = "1:602482355230:web:6b8a15424fe32b47dc920f";
}

// Init App
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const db = getFirestore(app);
export const auth = getAuth(app);

export async function authenticateUser() {
    try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
            await signInWithCustomToken(auth, __initial_auth_token);
        } else {
            await signInAnonymously(auth);
        }
    } catch (error: any) {
        console.error("Auth Error:", error.message);
    }
}

// --- CORRECTION DES CHEMINS (POINTAGE VERS LA RACINE) ---

export const MEDIA_PLANS_COLLECTION = "Media-plans";
export const INSERTIONS_COLLECTION = "Insertions";
export const ANNONCEURS_COLLECTION = "annonceurs";
export const MARQUES_COLLECTION = "marques";
export const CLIENTS_GROUPES_COLLECTION = "clientGroupes";

// Collections de Paramétrage
export const CANAUX_COLLECTION = "Canaux";
export const FORMATS_COLLECTION = "Formats";
export const BUYING_MODELS_COLLECTION = "Buying-models";
export const LOGOS_COLLECTION = "logos"; // Logos clients

// --- NOUVEAUTÉS ---
export const AGENCE_SETTINGS_COLLECTION = "agenceSettings"; // Paramètres Agence (Logos)
export const THEMES_COLLECTION = "themes"; // <-- NOUVEAU : Moteur de Design

console.log(`[Firebase] Mode Racine activé. Collection Plans: ${MEDIA_PLANS_COLLECTION}`);