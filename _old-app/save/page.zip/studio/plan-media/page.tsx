'use client';

import React, { useState, useEffect, useMemo, useRef } from 'react';
import Link from 'next/link';
import { 
  Database, Loader2, Search, Share2, Check, Copy, ExternalLink, X, 
  Calendar, Globe, Clock, History, FileText, Edit3, Save, RotateCcw, 
  Plus, Trash2, AlertCircle, Percent, TrendingUp, DollarSign, Eye, MousePointerClick, PlayCircle, Target, Home, Clock10, Settings, BarChart3,
  Layers, Scan, Users, Info, Palette, ChevronDown, Layout, Grid, ChevronRight, Briefcase, ToggleLeft, ToggleRight, BarChart4
} from 'lucide-react';

// UI
import StudioLayout from "../../components/StudioLayout";
import DashboardRenderer from "../../components/DashboardRenderer"; 

// Firebase
import { 
    db, 
    authenticateUser, 
    MEDIA_PLANS_COLLECTION, 
    INSERTIONS_COLLECTION, 
    ANNONCEURS_COLLECTION, 
    MARQUES_COLLECTION,
    FORMATS_COLLECTION,
    LOGOS_COLLECTION,
    AGENCE_SETTINGS_COLLECTION, 
    THEMES_COLLECTION 
} from '../../lib/firebase'; 

// Ajout des fonctions d'écriture manquantes
import { collection, doc, getDoc, query, where, onSnapshot, getDocs, updateDoc, writeBatch } from 'firebase/firestore'; 

// --- TYPES ---
interface AvailablePlan {
    id: string;
    title: string;
    annonceurId: string;
    totalBudget: number;
    status: string;
    startDate: string;
    endDate: string;
}

interface PublishedReport {
    id: string;
    title: string;
    url: string;
    date: string;
    annonceur: string;
}

interface AgenceSettings {
    iconeDarkUrl: string;
    logoDarkUrl: string;
    iconeLightUrl: string;
    logoLightUrl: string;
    activeThemeId: string;
    commissionRate: number; 
    feesRate: number;       
}

interface Theme {
    id: string;
    name: string;
    previewBg: string; 
    description: string; 
    themeColors: {
        primaryAccent: string; 
        secondaryAccent: string; 
        background: string; 
        text: string; 
    }
}

// --- THÈMES PAR DÉFAUT ---
const defaultThemes: Theme[] = [
    { 
        id: 'dark-vibrant', 
        name: 'Nuit Vive (Vibrant Dark)', 
        previewBg: '#111827', 
        description: "Fond sombre, accent bleu moderne.", 
        themeColors: {
            primaryAccent: '#3B82F6', 
            secondaryAccent: '#8B5CF6', 
            background: '#111827', 
            text: '#F8FAFC',
        }
    },
    { 
        id: 'light-corporate', 
        name: 'Clair Pro (Corporate Light)', 
        previewBg: '#F0F4F8', 
        description: "Fond blanc, look professionnel et aéré.", 
        themeColors: {
            primaryAccent: '#0668E1', 
            secondaryAccent: '#475569', 
            background: '#FFFFFF',
            text: '#0F172A',
        }
    },
    { 
        id: 'obsidian-gold', 
        name: 'Luxe Obsidian (Premium)', 
        previewBg: '#000000', 
        description: "Noir pur et accents dorés pour le luxe.", 
        themeColors: {
            primaryAccent: '#D4AF37', 
            secondaryAccent: '#78716C', 
            background: '#020202', 
            text: '#E5E5E5',
        }
    },
];

// --- CONSTANTES PAR DEFAUT (Fallback) ---
const DEFAULT_BENCHMARKS = {
    CTR_DISPLAY: 0.2, // en %
    CTR_SEARCH: 5.0,  // en %
    VTR_VIDEO: 45.0,  // en %
    CONV_RATE: 2.0    // en %
};

// --- HOOK DESIGN ---
function useAgenceDesign() {
    const [design, setDesign] = useState<{ settings: AgenceSettings | null, themes: Theme[] } | null>(null);

    useEffect(() => {
        const fetchDesign = async () => {
            try {
                await authenticateUser();
                const settingsRef = doc(db, AGENCE_SETTINGS_COLLECTION, 'main');
                const settingsSnap = await getDoc(settingsRef);
                const defaultSettings: AgenceSettings = { 
                    iconeDarkUrl: '', logoDarkUrl: '', iconeLightUrl: '', logoLightUrl: '', 
                    activeThemeId: 'dark-vibrant', commissionRate: 15, feesRate: 0 
                } as AgenceSettings;
                const settingsData = settingsSnap.exists() ? { ...defaultSettings, ...settingsSnap.data() } : defaultSettings;

                const themesSnap = await getDoc(doc(db, THEMES_COLLECTION, 'list'));
                let themesList = defaultThemes;
                if (themesSnap.exists() && themesSnap.data().availableThemes && Array.isArray(themesSnap.data().availableThemes)) {
                    const fetchedThemes = themesSnap.data().availableThemes as Theme[];
                    if(fetchedThemes.length > 0) themesList = fetchedThemes;
                }
                setDesign({ settings: settingsData, themes: themesList });
            } catch (err) { 
                console.warn("Erreur chargement design, fallback.", err);
                setDesign({ settings: defaultThemes[0] as unknown as AgenceSettings, themes: defaultThemes });
            }
        };
        fetchDesign();
    }, []);
    return design;
}

// --- DATA HOOK ---
function usePlanData(planId: string | null) {
    const [data, setData] = useState<any>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!planId) { setData(null); return; }
        setLoading(true); setError(null);

        authenticateUser().then(async () => {
            try {
                const planRef = doc(db, MEDIA_PLANS_COLLECTION, planId);
                const planSnap = await getDoc(planRef);
                if (!planSnap.exists()) throw new Error("Plan introuvable");
                const planData = { id: planSnap.id, ...planSnap.data() } as any;

                let annonceurData: any = null; 
                const rawAnnId = planData.annonceurRef || planData.annonceurId || planData.clientRef;
                if (rawAnnId) {
                    const annId = typeof rawAnnId === 'object' && rawAnnId.id ? rawAnnId.id : rawAnnId;
                    if (typeof annId === 'string') {
                        const annSnap = await getDoc(doc(db, ANNONCEURS_COLLECTION, annId));
                        annonceurData = annSnap.exists() ? { id: annSnap.id, ...annSnap.data() } : { id: annId };
                        try {
                           const logoSnap = await getDoc(doc(db, LOGOS_COLLECTION, annId));
                           if (logoSnap.exists() && logoSnap.data().logoUrl) {
                              if (annonceurData) annonceurData.logoUrl = logoSnap.data().logoUrl;
                           }
                        } catch (e) { console.warn("Logo client non trouvé", e); }
                    }
                }

                let marquesData: any[] = [];
                let marqueIdsArray: string[] = [];
                const rawMarques = planData.marquesRefs || planData.marqueIds;
                if (Array.isArray(rawMarques)) marqueIdsArray = rawMarques;
                else if (typeof rawMarques === 'string') marqueIdsArray = rawMarques.split(/[;,]/).map((s: string) => s.trim());

                if (marqueIdsArray.length > 0) {
                    const results = await Promise.all(marqueIdsArray.map(async (mId) => {
                        if (!mId) return null;
                        const cleanId = mId.replace('marques/', '');
                        const mSnap = await getDoc(doc(db, MARQUES_COLLECTION, cleanId));
                        return mSnap.exists() ? { id: mId, ...mSnap.data() } : null; 
                    }));
                    marquesData = results.filter(m => m !== null);
                }

                let formatsData: any[] = [];
                try {
                    const formatsSnap = await getDocs(collection(db, FORMATS_COLLECTION));
                    formatsData = formatsSnap.docs.map(d => ({ id: d.id, ...d.data() }));
                } catch (e) { console.warn("Formats non chargés", e); }

                let q = query(collection(db, INSERTIONS_COLLECTION), where("planRef", "==", planId));
                const unsubscribe = onSnapshot(q, (snapshot) => {
                    const insertions = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
                    setData({ plan: planData, annonceur: annonceurData, marques: marquesData, insertions, formats: formatsData });
                    setLoading(false);
                }, (err) => { console.error(err); setError("Erreur insertions"); setLoading(false); });
                return () => unsubscribe();

            } catch (err: any) { console.error(err); setError(err.message); setLoading(false); }
        });
    }, [planId]);
    return { data, loading, error };
}

// --- SYSTEM CLOCK ---
function SystemClock() {
    const [time, setTime] = useState<Date | null>(null);
    useEffect(() => {
        setTime(new Date());
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);
    if (!time) return <div className="w-16 h-4 bg-slate-800/50 rounded animate-pulse"></div>;
    return (
        <div className="font-mono text-[10px] text-indigo-400 flex items-center gap-2 bg-[#0F172A] px-2 py-1 rounded border border-slate-800 shadow-sm">
            <Clock size={10} />
            {time.toLocaleTimeString('fr-FR')}
        </div>
    );
}

// --- GENERATEUR DE DASHBOARD (CODE STRING) ---
// MODIFICATION : Accepte maintenant les paramètres de simulation
const generateDashboardCode = (colors: Theme['themeColors'], logoUrl: string | null, params: any) => `
const THEME_COLORS = {
    primary: '${colors.primaryAccent}',
    secondary: '${colors.secondaryAccent}',
    background: '${colors.background}',
    text: '${colors.text}',
    logoUrl: '${logoUrl || ''}' 
};
const DYNAMIC_COLORS = [THEME_COLORS.primary, THEME_COLORS.secondary, '#f59e0b', '#ef4444', '#8b5cf6', '#06B6D4'];

// CONSTANTES DYNAMIQUES (INJECTÉES)
const CTR_DISPLAY = ${params.ctrDisplay ? params.ctrDisplay / 100 : 0.002}; 
const CTR_SEARCH = ${params.ctrSearch ? params.ctrSearch / 100 : 0.05}; 
const VTR_VIDEO = ${params.vtrVideo ? params.vtrVideo / 100 : 0.45}; 
const CPA_LEADS = ${params.convRate ? params.convRate / 100 : 0.02};

const getUnitLabel = (model) => {
    const m = (model || '').toUpperCase();
    if (m === 'CPM') return 'Impressions';
    if (m === 'CPC') return 'Clics';
    if (m === 'CPV') return 'Vues';
    if (m === 'CPL') return 'Leads';
    if (m === 'FLAT' || m === 'FORFAIT') return 'Forfait';
    return 'Unités';
};

const simulateMetrics = (insertion, ctrDisplay, ctrSearch, vtrVideo, cpaLeads) => {
    const model = (insertion.modeleAchat || insertion.buyingModelId || 'FLAT').toUpperCase();
    const volAchete = insertion.quantiteAchetee || insertion.volumeEst || 0;
    const canal = (insertion.canal || insertion.channelId || '').toLowerCase();
    let activeCTR = ctrDisplay;
    if (canal.includes('google') || canal.includes('search')) activeCTR = ctrSearch;
    let imp = 0, clics = 0, vues = 0, leads = 0;

    if (model === 'CPM') { imp = volAchete; clics = imp * activeCTR; if (canal.includes('video')) vues = imp * vtrVideo; } 
    else if (model === 'CPC') { clics = volAchete; imp = activeCTR > 0 ? clics / activeCTR : 0; if (canal.includes('video')) vues = imp * vtrVideo; } 
    else if (model === 'CPV') { vues = volAchete; imp = vtrVideo > 0 ? vues / vtrVideo : 0; clics = imp * activeCTR; } 
    else if (model === 'CPL') { leads = volAchete; clics = cpaLeads > 0 ? leads / cpaLeads : 0; imp = activeCTR > 0 ? clics / activeCTR : 0; }
    if (model !== 'CPL') leads = clics * cpaLeads;
    return { impressions: Math.round(imp), clics: Math.round(clics), vues: Math.round(vues), leads: Math.round(leads), unitLabel: getUnitLabel(model) };
};

const { plan, annonceur, marques, insertions, formats } = rawPlanData;

if (!plan) {
  render(<div className="flex flex-col items-center justify-center h-full text-slate-500 gap-6 select-none" style={{backgroundColor: THEME_COLORS.background, color: THEME_COLORS.text}}>
      <p className="font-medium text-sm tracking-[0.2em] uppercase">Sélectionnez un plan média</p>
    </div>);
  return;
}

const formatDate = (ts) => {
    if (!ts) return null;
    if (ts.seconds) return new Date(ts.seconds * 1000).toLocaleDateString('fr-FR');
    return new Date(ts).toLocaleDateString('fr-FR');
};
const calcDuration = (start, end) => {
    if (!start || !end) return 0;
    const d1 = start.seconds ? new Date(start.seconds * 1000) : new Date(start);
    const d2 = end.seconds ? new Date(end.seconds * 1000) : new Date(end);
    return Math.ceil(Math.abs(d2 - d1) / (1000 * 60 * 60 * 24));
};

const duration = calcDuration(plan.dateDebut || plan.startDate, plan.dateFin || plan.endDate);
const insertionsWithMetrics = insertions.map(ins => {
    const formatSpec = (formats || []).find(f => f.id === ins.format || f.name === ins.format || (ins.format && f.name && f.name.toLowerCase().includes(ins.format.toLowerCase())));
    return {
        ...ins, metrics: simulateMetrics(ins, CTR_DISPLAY, CTR_SEARCH, VTR_VIDEO, CPA_LEADS),
        objectif: ins.objectif || plan.objectifPrincipal || '-',
        budgetNet: ins.coutEstime || ins.budget || 0,
        volumeAchete: ins.quantiteAchetee || ins.volumeEst || 0,
        unitCost: ins.coutUnitaire || ins.unitCost || 0,
        techSpecs: formatSpec || { specsDimensions: '-', specsMaxWeight: '-', specsFileType: '-', name: null }
    };
});

const dataToUse = insertionsWithMetrics;
const totalNetMedia = dataToUse.reduce((acc, i) => acc + i.budgetNet, 0);
const totalImp = dataToUse.reduce((acc, i) => acc + i.metrics.impressions, 0);
const totalClics = dataToUse.reduce((acc, i) => acc + i.metrics.clics, 0);
const totalVues = dataToUse.reduce((acc, i) => acc + i.metrics.vues, 0);
const totalLeads = dataToUse.reduce((acc, i) => acc + i.metrics.leads, 0);

// --- GESTION FRAIS & COM ---
const tauxComm = plan.showCommission !== false ? (plan.commissionRate || 10) : 0;
const tauxFrais = plan.showFees !== false ? (plan.feesRate || 0) : 0;

const commissionAgence = totalNetMedia * (tauxComm / 100);
const fraisTechniques = totalNetMedia * (tauxFrais / 100);
const totalInvestiHT = totalNetMedia + commissionAgence + fraisTechniques;
const dataCanal = dataToUse.reduce((acc, ins) => {
  const c = ins.canal || ins.channelId || 'Autre'; const v = ins.budgetNet;
  const existing = acc.find(x => x.name === c); if (existing) existing.value += v; else acc.push({ name: c, value: v });
  return acc;
}, []).sort((a,b) => b.value - a.value);

const kpis = [
  { label: "Net Média Investi", val: totalNetMedia.toLocaleString('fr-FR'), unit: "MAD", icon: Lucide.Target, color: THEME_COLORS.text, show: true },
  { label: "Impressions Est.", val: (totalImp / 1000000).toFixed(1), unit: "M", icon: Lucide.Eye, color: THEME_COLORS.primary, show: totalImp > 0 },
  { label: "Clics Est.", val: (totalClics / 1000).toFixed(1), unit: "K", icon: Lucide.MousePointerClick, color: THEME_COLORS.secondary, show: totalClics > 0 },
  { label: "Vues Vidéo Est.", val: (totalVues / 1000).toFixed(1), unit: "K", icon: Lucide.PlayCircle, color: '#EC4899', show: totalVues > 0 },
].filter(k => k.show);

const getInsertionLabel = (ins, index) => ins.nomInsertion || ins.name || (ins.techSpecs && ins.techSpecs.name) || (ins.format && (ins.format.startsWith('INS-') || ins.format.startsWith('FMT-')) ? ins.canal + ' #' + (index + 1) : ins.format || \`Insertion #\${index + 1}\`);

const Dashboard = () => {
    const [activeTab, setActiveTab] = useState('retombees');
    const bgColor = THEME_COLORS.background; const textColor = THEME_COLORS.text; const primaryColor = THEME_COLORS.primary; const secondaryColor = THEME_COLORS.secondary;
    const cardBg = bgColor === '#FFFFFF' ? '#F0F4F8' : '#1E293B'; const borderStyle = { borderColor: secondaryColor + '55', backgroundColor: cardBg }; const headerBg = bgColor === '#FFFFFF' ? '#F8FAFC' : cardBg;
    const mutedText = bgColor === '#FFFFFF' ? 'text-slate-600' : 'text-slate-500'; const totalColor = bgColor === '#FFFFFF' ? '#059669' : '#34D399'; 

    return (
      <div className="min-h-full font-sans pb-12 selection:bg-indigo-500/30" style={{backgroundColor: bgColor, color: textColor}}>
        <div className="border-b" style={{borderColor: secondaryColor + '22', backgroundColor: headerBg}}>
          <div className="flex justify-between items-start max-w-7xl mx-auto px-8 py-8">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-2">
                 <h1 className="text-3xl font-bold tracking-tight" style={{color: textColor}}>{plan.nomPlan || plan.name}</h1>
                 <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border" style={{borderColor: secondaryColor + '55', color: mutedText}}>
                   {plan.status || 'Brouillon'}
                 </span>
              </div>
              <div className="flex flex-col gap-2 mt-2">
                  <div className="flex items-center text-sm gap-3" style={{color: mutedText}}>
                    <span className="font-semibold" style={{color: textColor}}>{annonceur ? (annonceur.nomAnnonceur || annonceur.annonceur) : '...'}</span>
                    <span className="text-slate-600">/</span>
                    <span style={{color: primaryColor}}>{marques.map(m => m.nomMarque || m.name).join(', ') || 'Global'}</span>
                  </div>
                  {plan.description && <div className="flex items-start gap-2 text-xs max-w-2xl mt-1 italic" style={{color: mutedText}}><Lucide.Info size={14} className="mt-0.5 shrink-0" />{plan.description}</div>}
              </div>
            </div>
            <div className="text-right flex flex-col items-end gap-4">
               {THEME_COLORS.logoUrl && <div className="mb-1"><img src={THEME_COLORS.logoUrl} alt="Agence" className="h-10 w-auto object-contain opacity-90" style={{ maxWidth: '180px' }} /></div>}
               <div><div className="text-[10px] uppercase font-bold tracking-widest mb-1" style={{color: mutedText}}>Total Investissement HT</div><div className="text-3xl font-bold font-mono tracking-tight" style={{color: totalColor}}>{totalInvestiHT.toLocaleString('fr-FR')} <span className="text-sm font-normal" style={{color: mutedText}}>MAD</span></div></div>
               <div className="flex items-center gap-3 px-3 py-2 rounded-lg border" style={{borderColor: secondaryColor + '55', backgroundColor: cardBg}}>
                    <Lucide.Calendar size={14} style={{color: primaryColor}}/><div className="text-xs font-mono" style={{color: textColor}}>{formatDate(plan.dateDebut || plan.startDate) || '--/--/----'} <span className="mx-2" style={{color: mutedText}}>➔</span> {formatDate(plan.dateFin || plan.endDate) || '--/--/----'}</div>
                    {duration > 0 && <div className="ml-2 pl-3 border-l text-[10px] font-bold uppercase tracking-wide" style={{borderColor: secondaryColor + '55', color: secondaryColor}}>{duration} Jours</div>}
               </div>
            </div>
          </div>
        </div>

        <div className="px-8 py-8 max-w-7xl mx-auto space-y-8">
          <div className={\`grid grid-cols-1 md:grid-cols-\${kpis.length > 4 ? 4 : kpis.length} gap-6\`}>
             {kpis.map((kpi, i) => (<div key={i} className="p-5 rounded-xl border shadow-lg relative overflow-hidden group" style={borderStyle}><div className="flex justify-between items-start mb-2"><span className="text-[10px] font-bold uppercase tracking-widest" style={{color: mutedText}}>{kpi.label}</span><kpi.icon size={16} style={{color: kpi.color}} className="opacity-80" /></div><div className="text-2xl font-bold font-mono" style={{color: kpi.color === THEME_COLORS.text ? textColor : kpi.color}}>{kpi.val} <span className="text-sm font-normal" style={{color: mutedText}}>{kpi.unit}</span></div></div>))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
             <div className="lg:col-span-2 rounded-xl border flex flex-col overflow-hidden shadow-lg" style={borderStyle}>
                <div className="px-6 py-4 border-b flex justify-between items-center" style={{borderColor: secondaryColor + '33', backgroundColor: headerBg}}><h3 className="font-bold text-sm flex items-center gap-2" style={{color: textColor}}><Lucide.List size={16} style={{color: primaryColor}}/>Plan Média & Budget</h3></div>
                <div className="flex-1 overflow-x-auto">
                   <table className="w-full text-xs text-left">
                     <thead className="text-[10px] uppercase font-bold border-b" style={{borderColor: secondaryColor + '55', backgroundColor: bgColor, color: mutedText}}><tr><th className="px-4 py-3 pl-6">Support / Format</th><th className="px-4 py-3">Modèle / Unité</th><th className="px-4 py-3 text-right">Vol. Est.</th><th className="px-4 py-3 text-right">C.U.</th><th className="px-4 py-3 text-right">Budget Net</th><th className="px-4 py-3 text-right pr-6">%</th></tr></thead>
                     <tbody className="divide-y" style={{borderColor: secondaryColor + '33'}}>
                       {dataToUse.map((ins, i) => { const budget = ins.budgetNet; const part = totalNetMedia > 0 ? (budget / totalNetMedia) * 100 : 0;
                         return (<tr key={i} className="transition-colors group" style={{color: textColor}}><td className="px-4 py-3 pl-6"><div className="font-bold line-clamp-1" style={{color: textColor}}>{ins.canal || ins.channelId}</div><div className="text-[10px]" style={{color: mutedText}}>{getInsertionLabel(ins, i)}</div></td><td className="px-4 py-3 flex items-center gap-2"><span className="font-bold font-mono">{ins.modeleAchat || ins.buyingModelId}</span><span className="text-[10px] uppercase" style={{color: mutedText}}>{ins.metrics.unitLabel}</span></td><td className="px-4 py-3 text-right font-mono font-medium" style={{color: mutedText}}>{ins.volumeAchete.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono" style={{color: mutedText}}>{ins.unitCost.toFixed(2)}</td><td className="px-4 py-3 text-right font-bold font-mono" style={{color: primaryColor}}>{budget.toLocaleString()}</td><td className="px-4 py-3 text-right pr-6 font-mono" style={{color: mutedText}}>{part.toFixed(1)}%</td></tr>)})}
                     </tbody>
                     <tfoot className="border-t-2" style={{borderColor: secondaryColor, backgroundColor: bgColor}}>
                        <tr><td colSpan={4} className="text-right px-4 py-2 font-medium uppercase text-[10px] tracking-wider" style={{color: mutedText}}>Total Net Média</td><td className="px-4 py-2 text-right font-bold font-mono" style={{color: textColor}}>{totalNetMedia.toLocaleString()}</td><td></td></tr>
                        {/* GESTION AFFICHAGE FRAIS DANS DASHBOARD */}
                        {plan.showCommission !== false && (<tr><td colSpan={4} className="text-right px-4 py-1 text-[10px]" style={{color: mutedText}}>Commission Agence ({tauxComm}%)</td><td className="px-4 py-1 text-right font-mono text-xs" style={{color: mutedText}}>{commissionAgence.toLocaleString()}</td><td></td></tr>)}
                        {plan.showFees !== false && (<tr><td colSpan={4} className="text-right px-4 py-1 text-[10px]" style={{color: mutedText}}>Frais Techniques ({tauxFrais}%)</td><td className="px-4 py-1 text-right font-mono text-xs" style={{color: mutedText}}>{fraisTechniques.toLocaleString()}</td><td></td></tr>)}
                        <tr className="border-t" style={{borderColor: secondaryColor + '55', backgroundColor: headerBg}}><td colSpan={4} className="text-right px-4 py-3 font-bold uppercase tracking-wider text-xs" style={{color: totalColor}}>Total Investissement HT</td><td className="px-4 py-3 text-right font-bold text-lg font-mono" style={{color: totalColor}}>{totalInvestiHT.toLocaleString()}</td><td className="px-4 py-3 text-right font-mono text-xs" style={{color: totalColor}}>MAD</td></tr>
                     </tfoot>
                   </table>
                </div>
             </div>
             <div className="rounded-xl border p-6 flex flex-col shadow-lg" style={borderStyle}>
                <h3 className="font-bold mb-4 text-xs uppercase tracking-widest flex items-center gap-2" style={{color: textColor}}><IconPieChart size={14} style={{color: primaryColor}}/> Répartition</h3>
                <div className="flex-1 w-full min-h-[250px]"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={dataCanal} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value" stroke="none">{dataCanal.map((entry, index) => <Cell key={'cell-' + index} fill={DYNAMIC_COLORS[index % DYNAMIC_COLORS.length]} />)}</Pie><Tooltip contentStyle={{borderRadius: '8px', border: '1px solid ' + secondaryColor + '55', backgroundColor: bgColor, color: textColor}} formatter={(val) => val.toLocaleString() + ' MAD'} /><Legend verticalAlign="bottom" iconType="circle" wrapperStyle={{fontSize: '10px', color: mutedText}} /></PieChart></ResponsiveContainer></div>
             </div>
          </div>
          <div className="rounded-xl border flex flex-col overflow-hidden shadow-lg mt-8" style={borderStyle}>
                <div className="flex items-center border-b" style={{borderColor: secondaryColor + '33', backgroundColor: bgColor}}>
                    <button onClick={() => setActiveTab('retombees')} className={\`px-6 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 \${activeTab === 'retombees' ? 'text-white' : mutedText}\`} style={{borderColor: activeTab === 'retombees' ? primaryColor : 'transparent', backgroundColor: activeTab === 'retombees' ? cardBg : bgColor}}><Lucide.BarChart3 size={14} style={{color: activeTab === 'retombees' ? primaryColor : mutedText}}/> Estimations</button>
                    <button onClick={() => setActiveTab('specs')} className={\`px-6 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 \${activeTab === 'specs' ? 'text-white' : mutedText}\`} style={{borderColor: activeTab === 'specs' ? secondaryColor : 'transparent', backgroundColor: activeTab === 'specs' ? cardBg : bgColor}}><Lucide.Scan size={14} style={{color: activeTab === 'specs' ? secondaryColor : mutedText}}/> Specs Techniques</button>
                    {/* RESTAURATION ONGLET CIBLAGE */}
                    <button onClick={() => setActiveTab('ciblages')} className={\`px-6 py-4 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center gap-2 \${activeTab === 'ciblages' ? 'text-white' : mutedText}\`} style={{borderColor: activeTab === 'ciblages' ? primaryColor : 'transparent', backgroundColor: activeTab === 'ciblages' ? cardBg : bgColor}}><Lucide.Users size={14} style={{color: activeTab === 'ciblages' ? primaryColor : mutedText}}/> Ciblages</button>
                </div>
                {activeTab === 'retombees' && (
                    <div className="overflow-x-auto animate-in fade-in duration-300">
                        <div className="px-6 py-4 flex justify-between items-center border-b" style={{borderColor: secondaryColor + '33', backgroundColor: cardBg, color: textColor}}><h3 className="font-bold text-sm">Tableau de Bord de Performance</h3><span className="text-[10px] hidden md:inline" style={{color: mutedText}}>Benchmarks : CTR Search \${(CTR_SEARCH*100).toFixed(0)}% / Display \${(CTR_DISPLAY*100).toFixed(1)}% • VTR \${(VTR_VIDEO*100).toFixed(0)}% • Conv \${(CPA_LEADS*100).toFixed(0)}%</span></div>
                        <table className="w-full text-xs text-left"><thead className="text-[10px] uppercase font-bold border-b" style={{borderColor: secondaryColor + '55', backgroundColor: cardBg, color: mutedText}}><tr><th className="px-4 py-3 pl-6">Canal</th><th className="px-4 py-3 text-right">Impressions Est.</th><th className="px-4 py-3 text-right">Clics Est.</th><th className="px-4 py-3 text-right">Vues Est.</th><th className="px-4 py-3 text-right pr-6">Leads Est.</th></tr></thead><tbody className="divide-y" style={{borderColor: secondaryColor + '33', backgroundColor: bgColor}}>
                           {dataToUse.map((ins, i) => (<tr key={i} className="transition-colors group" style={{color: textColor}}><td className="px-4 py-3 pl-6"><div className="font-bold" style={{color: textColor}}>{ins.canal || ins.channelId}</div><div className="text-[10px] uppercase" style={{color: mutedText}}>{ins.modeleAchat}</div></td><td className={\`px-4 py-3 text-right font-mono \${ins.metrics.impressions > 0 ? '' : mutedText}\`} style={{color: ins.metrics.impressions > 0 ? primaryColor : mutedText}}>{ins.metrics.impressions > 0 ? ins.metrics.impressions.toLocaleString() : '-'}</td><td className={\`px-4 py-3 text-right font-mono \${ins.metrics.clics > 0 ? '' : mutedText}\`} style={{color: ins.metrics.clics > 0 ? secondaryColor : mutedText}}>{ins.metrics.clics > 0 ? ins.metrics.clics.toLocaleString() : '-'}</td><td className={\`px-4 py-3 text-right font-mono \${ins.metrics.vues > 0 ? '' : mutedText}\`} style={{color: ins.metrics.vues > 0 ? primaryColor : mutedText}}>{ins.metrics.vues > 0 ? ins.metrics.vues.toLocaleString() : '-'}</td><td className={\`px-4 py-3 text-right pr-6 font-mono \${ins.metrics.leads > 0 ? '' : mutedText}\`} style={{color: ins.metrics.leads > 0 ? secondaryColor : mutedText}}>{ins.metrics.leads > 0 ? ins.metrics.leads.toLocaleString() : '-'}</td></tr>))}
                         </tbody></table>
                    </div>
                )}
                {activeTab === 'specs' && (
                    <div className="overflow-x-auto animate-in fade-in duration-300">
                       <table className="w-full text-xs text-left"><thead className="text-[10px] uppercase font-bold border-b" style={{borderColor: secondaryColor + '55', backgroundColor: cardBg, color: mutedText}}><tr><th className="px-4 py-3 pl-6">Insertion / Canal</th><th className="px-4 py-3">Format Requis</th><th className="px-4 py-3">Dimensions</th><th className="px-4 py-3">Poids Max</th><th className="px-4 py-3 pr-6">Type de fichier</th></tr></thead><tbody className="divide-y" style={{borderColor: secondaryColor + '33', backgroundColor: bgColor}}>
                           {dataToUse.map((ins, i) => (<tr key={i} className="transition-colors" style={{color: textColor}}><td className="px-4 py-3 pl-6"><div className="font-bold" style={{color: textColor}}>{ins.canal}</div><div className="text-[10px]" style={{color: mutedText}}>{getInsertionLabel(ins, i)}</div></td><td className="px-4 py-3"><span className="font-medium">{ins.format}</span></td><td className="px-4 py-3 font-mono" style={{color: primaryColor}}>{ins.techSpecs.specsDimensions || '-'}</td><td className="px-4 py-3 font-mono" style={{color: mutedText}}>{ins.techSpecs.specsMaxWeight || '-'}</td><td className="px-4 py-3 pr-6 font-mono" style={{color: mutedText}}>{ins.techSpecs.specsFileType || '-'}</td></tr>))}
                       </tbody></table>
                    </div>
                )}
                {/* BLOC CIBLAGES RESTAURÉ */}
                {activeTab === 'ciblages' && (
                    <div className="overflow-x-auto animate-in fade-in duration-300">
                       <div className="px-6 py-4 flex justify-between items-center border-b" style={{borderColor: secondaryColor + '33', backgroundColor: cardBg, color: textColor}}>
                           <h3 className="font-bold text-sm">Stratégie de Ciblage</h3>
                           <span className="text-[10px] border px-2 py-1 rounded uppercase" style={{borderColor: primaryColor + '55', color: primaryColor, backgroundColor: primaryColor + '11'}}>Audience Map</span>
                        </div>
                       <table className="w-full text-xs text-left">
                         <thead className="text-[10px] uppercase font-bold border-b" style={{borderColor: secondaryColor + '55', backgroundColor: cardBg, color: mutedText}}>
                           <tr>
                             <th className="px-4 py-3 pl-6">Insertion</th>
                             <th className="px-4 py-3">Canal</th>
                             <th className="px-4 py-3 w-1/2 pr-6">Ciblage / Audience / Mots-clés</th>
                           </tr>
                         </thead>
                         <tbody className="divide-y" style={{borderColor: secondaryColor + '33', backgroundColor: bgColor}}>
                           {dataToUse.map((ins, i) => (
                            <tr key={i} className="transition-colors" style={{color: textColor}}>
                              <td className="px-4 py-3 pl-6 font-medium" style={{color: textColor}}>
                                {getInsertionLabel(ins, i)}
                              </td>
                              <td className="px-4 py-3">
                                 <div className="flex items-center gap-2">
                                    <span className="w-2 h-2 rounded-full" style={{backgroundColor: primaryColor}}></span>
                                    <span style={{color: textColor}}>{ins.canal}</span>
                                 </div>
                              </td>
                              <td className="px-4 py-3 pr-6">
                                 <div className="border rounded p-2 font-mono text-[11px]" style={{borderColor: secondaryColor + '55', backgroundColor: secondaryColor + '11', color: mutedText}}>
                                    {ins.targeting || ins.ciblage || 'Non spécifié'}
                                 </div>
                              </td>
                            </tr>
                           ))}
                         </tbody>
                       </table>
                    </div>
                )}
          </div>
        </div>
      </div>
    );
};
render(<Dashboard />);
`;

export default function StudioPage() {
    const design = useAgenceDesign(); 
    const [planId, setPlanId] = useState<string | null>(null);
    const [plansList, setPlansList] = useState<AvailablePlan[]>([]);
    const [localThemeId, setLocalThemeId] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [activeTab, setActiveTab] = useState<'drafts' | 'published'>('drafts');
    
    // Editing States
    const [isEditing, setIsEditing] = useState(false);
    const [editData, setEditData] = useState<any>(null);
    const [isSaving, setIsSaving] = useState(false);

    // Publish States
    const [publishModalOpen, setPublishModalOpen] = useState(false);
    const [lastPublishedUrl, setLastPublishedUrl] = useState<string | null>(null);
    const [isPublishing, setIsPublishing] = useState(false);
    
    // History
    const [historyList, setHistoryList] = useState<PublishedReport[]>([]);

    const { data: rawPlanData } = usePlanData(planId);
    
    const activeTheme = useMemo(() => {
        if (!design) return null; 
        const targetThemeId = localThemeId || design.settings?.activeThemeId;
        const theme = design.themes.find(t => t.id === targetThemeId) || design.themes[0] || {} as Theme;
        const isLight = theme.themeColors?.background.toLowerCase().includes('fff'); 
        const settings = design.settings || {} as AgenceSettings;
        return {
            ...theme,
            logoUrl: isLight ? settings.logoDarkUrl : settings.logoLightUrl,
            iconeUrl: isLight ? settings.iconeDarkUrl : settings.iconeLightUrl,
            themeColors: theme.themeColors || defaultThemes[0].themeColors,
        };
    }, [design, localThemeId]); 
    
    const currentCode = useMemo(() => {
        if (!activeTheme) return `render(<div className="p-8 text-slate-500">Chargement du Moteur de Design...</div>)`;
        
        // On récupère les params du plan actuel ou les defaults
        const params = rawPlanData?.plan ? {
            ctrDisplay: rawPlanData.plan.ctrDisplay || DEFAULT_BENCHMARKS.CTR_DISPLAY,
            ctrSearch: rawPlanData.plan.ctrSearch || DEFAULT_BENCHMARKS.CTR_SEARCH,
            vtrVideo: rawPlanData.plan.vtrVideo || DEFAULT_BENCHMARKS.VTR_VIDEO,
            convRate: rawPlanData.plan.convRate || DEFAULT_BENCHMARKS.CONV_RATE
        } : DEFAULT_BENCHMARKS;

        return generateDashboardCode(activeTheme.themeColors, activeTheme.logoUrl, params);
    }, [activeTheme, rawPlanData]);

    // --- LOGIQUE DE SIMULATION LIVE POUR L'ÉDITEUR ---
    const editorMetrics = useMemo(() => {
        if (!editData || !editData.insertions) return { imp: 0, clicks: 0, leads: 0 };
        
        // Récupération des taux personnalisés ou défauts
        // Note: Les taux sont stockés en % (ex: 0.2), on divise par 100 pour le calcul
        const CTR_D = (editData.plan.ctrDisplay ?? DEFAULT_BENCHMARKS.CTR_DISPLAY) / 100;
        const CTR_S = (editData.plan.ctrSearch ?? DEFAULT_BENCHMARKS.CTR_SEARCH) / 100;
        const VTR = (editData.plan.vtrVideo ?? DEFAULT_BENCHMARKS.VTR_VIDEO) / 100;
        const CVR = (editData.plan.convRate ?? DEFAULT_BENCHMARKS.CONV_RATE) / 100;

        let totalImp = 0, totalClicks = 0, totalLeads = 0;
        
        editData.insertions.forEach((ins: any) => {
            const model = (ins.modeleAchat || 'FLAT').toUpperCase();
            const vol = parseFloat(ins.quantiteAchetee || 0);
            const canal = (ins.canal || '').toLowerCase();
            
            let activeCTR = CTR_D;
            if (canal.includes('google') || canal.includes('search')) activeCTR = CTR_S;

            let imp = 0, clics = 0, leads = 0;

            if (model === 'CPM') {
                imp = vol;
                clics = imp * activeCTR;
            } else if (model === 'CPC') {
                clics = vol;
                imp = activeCTR > 0 ? clics / activeCTR : 0;
            } else if (model === 'CPV') {
                const vues = vol;
                imp = VTR > 0 ? vues / VTR : 0;
                clics = imp * activeCTR;
            } else if (model === 'CPL') {
                leads = vol;
                clics = CVR > 0 ? leads / CVR : 0;
                imp = activeCTR > 0 ? clics / activeCTR : 0;
            }

            if (model !== 'CPL') leads = clics * CVR;

            totalImp += imp;
            totalClicks += clics;
            totalLeads += leads;
        });

        return { imp: Math.round(totalImp), clicks: Math.round(totalClicks), leads: Math.round(totalLeads) };

    }, [editData]);

    useEffect(() => {
        const saved = localStorage.getItem('publishedHistory');
        if (saved) { try { setHistoryList(JSON.parse(saved)); } catch (e) { console.error(e); } }
    }, []);

    useEffect(() => {
        authenticateUser().then(() => {
            const q = query(collection(db, MEDIA_PLANS_COLLECTION));
            const unsubscribe = onSnapshot(q, (snap) => {
                const list = snap.docs.map(d => {
                    const data = d.data();
                    const fmtDate = (val: any) => {
                       if (val?.toDate) return val.toDate().toISOString().split('T')[0];
                       if (val?.seconds) return new Date(val.seconds * 1000).toISOString().split('T')[0];
                       return val || 'N/A';
                    };
                    return {
                        id: d.id,
                        title: data.nomPlan || data.name || 'Sans titre',
                        annonceurId: typeof data.annonceurRef === 'string' ? data.annonceurRef : '...',
                        totalBudget: data.budgetTotal || data.totalBudget || 0,
                        status: data.status || 'Brouillon',
                        startDate: fmtDate(data.dateDebut || data.startDate),
                        endDate: fmtDate(data.dateFin || data.endDate)
                    } as AvailablePlan;
                });
                setPlansList(list);
            });
            return () => unsubscribe();
        });
    }, []);

    useEffect(() => {
        if (isEditing && rawPlanData) {
            setEditData(JSON.parse(JSON.stringify(rawPlanData)));
        }
    }, [isEditing, rawPlanData]);

    const filteredPlans = useMemo(() => {
        if (activeTab === 'published') return []; 
        return plansList.filter(plan => {
            const searchLower = searchTerm.toLowerCase();
            return (
                plan.title.toLowerCase().includes(searchLower) ||
                plan.annonceurId.toLowerCase().includes(searchLower)
            );
        });
    }, [plansList, searchTerm, activeTab]);

    const handlePublish = async () => {
        if (!planId) return alert("Veuillez sélectionner un plan avant de publier.");
        if (!rawPlanData) return alert("Données non chargées.");
        
        setIsPublishing(true);
        try {
            const finalData = { ...rawPlanData, agenceDesign: activeTheme };
            const response = await fetch('/api/publish', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    title: rawPlanData.plan.nomPlan || "Plan Média",
                    code: currentCode, 
                    data: finalData
                })
            });
            const result = await response.json();
            if (result.success) {
                const url = `${window.location.origin}/dashboards/${result.slug}`;
                setLastPublishedUrl(url);
                const newReport: PublishedReport = {
                    id: result.slug, title: rawPlanData.plan.nomPlan || "Rapport", url: url, date: new Date().toLocaleDateString(),
                    annonceur: rawPlanData.annonceur?.nomAnnonceur || rawPlanData.plan.annonceurRef || '...'
                };
                const updatedHistory = [newReport, ...historyList];
                setHistoryList(updatedHistory);
                localStorage.setItem('publishedHistory', JSON.stringify(updatedHistory));
                setPublishModalOpen(true);
            } else { alert("Erreur : " + result.message); }
        } catch (e) { console.error(e); alert("Erreur réseau."); } 
        finally { setIsPublishing(false); }
    };

    const handleEditToggle = () => {
        if (!planId) return;
        setIsEditing(!isEditing);
    };

    const handleEditChange = (path: string, value: any, id?: string) => {
        if (!editData) return;
        const newData = { ...editData };
        
        if (path === 'plan.nomPlan') {
            newData.plan.nomPlan = value;
        } else if (path === 'plan.status') {
             newData.plan.status = value;
        } 
        // Gestion des frais
        else if (path === 'plan.commissionRate') newData.plan.commissionRate = parseFloat(value) || 0;
        else if (path === 'plan.feesRate') newData.plan.feesRate = parseFloat(value) || 0;
        else if (path === 'plan.showCommission') newData.plan.showCommission = value; // boolean
        else if (path === 'plan.showFees') newData.plan.showFees = value; // boolean
        
        // Gestion des Benchmarks
        else if (path === 'plan.ctrDisplay') newData.plan.ctrDisplay = parseFloat(value) || 0;
        else if (path === 'plan.ctrSearch') newData.plan.ctrSearch = parseFloat(value) || 0;
        else if (path === 'plan.vtrVideo') newData.plan.vtrVideo = parseFloat(value) || 0;
        else if (path === 'plan.convRate') newData.plan.convRate = parseFloat(value) || 0;

        else if (path.startsWith('insertion.') && id) {
            const insIndex = newData.insertions.findIndex((i: any) => i.id === id);
            if (insIndex > -1) {
                const field = path.split('.')[1];
                if (field === 'budget') {
                    const newBudget = parseFloat(value) || 0;
                    newData.insertions[insIndex].coutEstime = newBudget;
                    const vol = newData.insertions[insIndex].quantiteAchetee || 0;
                    if(vol > 0) newData.insertions[insIndex].coutUnitaire = newBudget / vol;
                }
                else if (field === 'volume') {
                    const newVol = parseFloat(value) || 0;
                    newData.insertions[insIndex].quantiteAchetee = newVol;
                    const cu = newData.insertions[insIndex].coutUnitaire || 0;
                    if (cu > 0) newData.insertions[insIndex].coutEstime = newVol * cu;
                }
                else if (field === 'canal') newData.insertions[insIndex].canal = value;
                else if (field === 'format') newData.insertions[insIndex].format = value;
                else if (field === 'modele') newData.insertions[insIndex].modeleAchat = value;
                else if (field === 'ciblage') newData.insertions[insIndex].targeting = value;
            }
        }
        setEditData(newData);
    };

    const handleSaveEdit = async () => {
        if (!planId || !editData) return;
        setIsSaving(true);
        
        // UX: Petit délai artificiel (min 800ms) pour :
        // 1. Montrer à l'utilisateur que "ça travaille" (feedback visuel rassurant)
        // 2. Laisser le temps à Firebase de mettre à jour le cache local avant de réafficher la vue lecture
        const safetyDelay = new Promise(resolve => setTimeout(resolve, 800));

        try {
            const planRef = doc(db, MEDIA_PLANS_COLLECTION, planId);
            
            // Préparation de la mise à jour du Plan
            const updatePlanPromise = updateDoc(planRef, {
                nomPlan: editData.plan.nomPlan,
                budgetTotal: editData.plan.budgetTotal,
                status: editData.plan.status || 'Brouillon',
                commissionRate: editData.plan.commissionRate,
                feesRate: editData.plan.feesRate,
                showCommission: editData.plan.showCommission ?? true,
                showFees: editData.plan.showFees ?? true,
                
                // Sauvegarde des Benchmarks
                ctrDisplay: editData.plan.ctrDisplay ?? DEFAULT_BENCHMARKS.CTR_DISPLAY,
                ctrSearch: editData.plan.ctrSearch ?? DEFAULT_BENCHMARKS.CTR_SEARCH,
                vtrVideo: editData.plan.vtrVideo ?? DEFAULT_BENCHMARKS.VTR_VIDEO,
                convRate: editData.plan.convRate ?? DEFAULT_BENCHMARKS.CONV_RATE,
            });

            // Préparation du Batch pour les Insertions
            const batch = writeBatch(db);
            editData.insertions.forEach((ins: any) => {
                const insRef = doc(db, INSERTIONS_COLLECTION, ins.id);
                batch.update(insRef, {
                    canal: ins.canal,
                    format: ins.format,
                    modeleAchat: ins.modeleAchat,
                    quantiteAchetee: ins.quantiteAchetee,
                    coutEstime: ins.coutEstime,
                    coutUnitaire: ins.coutUnitaire,
                    targeting: ins.targeting
                });
            });
            const batchPromise = batch.commit();

            // On attend que TOUT soit fini : DB + Délai UX
            await Promise.all([updatePlanPromise, batchPromise, safetyDelay]);

            setIsEditing(false);
        } catch (e) {
            console.error("Erreur sauvegarde", e);
            alert("Erreur lors de la sauvegarde.");
        } finally {
            setIsSaving(false);
        }
    };

    // --- COMPOSANT: DROPDOWN STATUT ---
    const StatusDropdown = ({ currentStatus, onChange }: { currentStatus: string, onChange: (val: string) => void }) => {
        const [isOpen, setIsOpen] = useState(false);
        const options = ['Brouillon', 'Planifié', 'En cours', 'Terminé', 'Archivé'];
        const ref = useRef<HTMLDivElement>(null);

        useEffect(() => {
            const handleClickOutside = (event: MouseEvent) => {
                if (ref.current && !ref.current.contains(event.target as Node)) setIsOpen(false);
            };
            document.addEventListener('mousedown', handleClickOutside);
            return () => document.removeEventListener('mousedown', handleClickOutside);
        }, []);

        const getColor = (s: string) => {
            switch(s) {
                case 'Planifié': return 'text-blue-400 border-blue-500/30 bg-blue-500/10';
                case 'En cours': return 'text-amber-400 border-amber-500/30 bg-amber-500/10';
                case 'Terminé': return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
                default: return 'text-slate-400 border-slate-700 bg-slate-800/50';
            }
        };

        return (
            <div className="relative" ref={ref}>
                <button 
                    onClick={() => setIsOpen(!isOpen)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider border transition-all ${getColor(currentStatus)} hover:bg-opacity-20`}
                >
                    {currentStatus} <ChevronDown size={12} />
                </button>
                {isOpen && (
                    <div className="absolute top-full left-0 mt-2 w-40 bg-[#1E293B] border border-slate-700 rounded-lg shadow-xl z-50 overflow-hidden">
                        {options.map(opt => (
                            <button key={opt} onClick={() => { onChange(opt); setIsOpen(false); }} className="w-full text-left px-4 py-2 text-xs font-medium text-slate-300 hover:bg-slate-700 hover:text-white transition-colors flex justify-between items-center">
                                {opt}
                                {currentStatus === opt && <Check size={12} className="text-emerald-400"/>}
                            </button>
                        ))}
                    </div>
                )}
            </div>
        );
    };

    const renderSidebar = (
        <div className="flex flex-col h-full bg-[#020617] border-r border-slate-800 w-80 text-slate-300">
            {/* Header Sidebar */}
            <div className="p-6 border-b border-slate-800/60 bg-[#020617]">
                <div className="flex items-center justify-between mb-6">
                     <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-indigo-900/40">
                            <Grid size={16} />
                        </div>
                        <span className="font-bold text-sm tracking-wide text-white">MediaHub</span>
                     </div>
                     <div className="text-[10px] font-mono text-slate-500 bg-slate-900 px-2 py-1 rounded border border-slate-800">v2.2</div>
                </div>

                <div className="relative group mb-4">
                    <Search size={14} className="absolute left-3 top-3 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
                    <input type="text" placeholder="Rechercher un plan..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-[#0F172A] border border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 text-slate-200 transition-all placeholder:text-slate-600 shadow-inner" />
                </div>

                <div className="flex bg-[#0F172A] p-1 rounded-xl border border-slate-800/80">
                    <button onClick={() => setActiveTab('drafts')} className={`flex-1 text-[11px] py-2 font-bold rounded-lg transition-all flex justify-center items-center gap-2 ${activeTab === 'drafts' ? 'bg-[#1E293B] text-indigo-400 shadow-md border border-slate-700' : 'text-slate-500 hover:text-slate-300'}`}>
                        <Layout size={12}/> Plans ({filteredPlans.length})
                    </button>
                    <button onClick={() => setActiveTab('published')} className={`flex-1 text-[11px] py-2 font-bold rounded-lg transition-all flex justify-center items-center gap-2 ${activeTab === 'published' ? 'bg-[#1E293B] text-emerald-400 shadow-md border border-slate-700' : 'text-slate-500 hover:text-slate-300'}`}>
                        <History size={12}/> Archives
                    </button>
                </div>
            </div>
            
            {/* Liste Plans Améliorée */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
                {activeTab === 'drafts' && (
                    <>
                        <div className="text-[10px] uppercase font-bold text-slate-600 tracking-widest px-2 mb-2 mt-2">Récemment modifiés</div>
                        {filteredPlans.map(plan => (
                            <button key={plan.id} onClick={() => { setPlanId(plan.id); setIsEditing(false); }}
                                className={`w-full group text-left p-4 rounded-2xl border transition-all duration-300 relative overflow-hidden ${plan.id === planId ? 'bg-gradient-to-br from-[#1E293B] to-[#0F172A] border-indigo-500/40 shadow-xl shadow-indigo-900/10' : 'bg-[#0F172A]/40 border-slate-800/60 hover:bg-[#1E293B] hover:border-slate-700'}`}>
                                
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex items-center gap-2">
                                        <div className={`w-1.5 h-1.5 rounded-full ${plan.id === planId ? 'bg-indigo-400 shadow-[0_0_8px_rgba(129,140,248,0.8)]' : 'bg-slate-600'}`}></div>
                                        <span className={`text-xs font-bold line-clamp-1 ${plan.id === planId ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`}>{plan.title}</span>
                                    </div>
                                    {plan.id === planId && <ChevronRight size={14} className="text-indigo-500 animate-pulse" />}
                                </div>
                                
                                <div className="pl-3.5 space-y-1">
                                    <div className="flex justify-between items-center text-[10px] text-slate-500">
                                        <div className="flex items-center gap-1.5">
                                            <Briefcase size={10} />
                                            <span className="uppercase tracking-wide">{plan.annonceurId}</span>
                                        </div>
                                    </div>
                                    <div className="flex justify-between items-end border-t border-slate-800/50 pt-2 mt-2">
                                         <span className={`text-[10px] px-2 py-0.5 rounded border ${plan.status === 'Planifié' ? 'text-blue-400 border-blue-500/20 bg-blue-500/10' : 'text-slate-500 border-slate-700 bg-slate-800/30'}`}>{plan.status || 'Brouillon'}</span>
                                         <span className={`font-mono text-xs font-bold ${plan.id === planId ? 'text-indigo-400' : 'text-slate-400'}`}>{(plan.totalBudget).toLocaleString()} <span className="text-[9px]">MAD</span></span>
                                    </div>
                                </div>
                            </button>
                        ))}
                    </>
                )}

                {activeTab === 'published' && historyList.map(report => (
                    <div key={report.id} className="w-full text-left p-4 rounded-2xl border border-slate-800 bg-[#0F172A]/50 hover:bg-[#1E293B] group relative overflow-hidden transition-all">
                        <div className="flex justify-between items-start mb-1">
                            <div className="font-bold text-sm text-slate-300 line-clamp-1 group-hover:text-white transition-colors">{report.title}</div>
                            <a href={report.url} target="_blank" className="text-indigo-400 hover:text-white p-1.5 bg-slate-800 rounded-lg border border-slate-700 hover:border-indigo-500 transition-colors"><ExternalLink size={12}/></a>
                        </div>
                        <div className="flex justify-between items-center text-[10px] text-slate-500 mt-3 border-t border-slate-800/50 pt-2">
                            <span className="flex items-center gap-1"><Briefcase size={10}/> {report.annonceur}</span>
                            <span className="font-mono">{report.date}</span>
                        </div>
                    </div>
                ))}
            </div>

             {/* Footer Thème (Quick View) */}
             {activeTheme && (
                <div className="p-4 border-t border-slate-800 bg-[#020617] text-[10px] text-slate-500 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full border border-slate-600" style={{backgroundColor: activeTheme.themeColors.primaryAccent}}></div>
                        <span>{activeTheme.name.split('(')[0]}</span>
                    </div>
                    <Link href="/studio/settings" className="hover:text-white transition-colors"><Settings size={12}/></Link>
                </div>
            )}
        </div>
    );

    const renderEditor = () => {
        if (!editData) return <div className="p-12 text-center text-slate-500 flex flex-col items-center gap-4"><Loader2 className="animate-spin"/> Chargement des données...</div>;
        
        return (
            <div className="min-h-full bg-[#0F172A] font-sans text-slate-100 pb-20 selection:bg-indigo-500/30 overflow-auto">
                
                {/* --- BARRE DE VALIDATION & KPIS FLOTTANTE --- */}
                <div className="sticky top-0 z-30 bg-[#1E293B]/95 backdrop-blur-md border-b border-indigo-500/30 px-6 py-4 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                        <div className="p-2 bg-indigo-500/20 rounded-lg text-indigo-400 animate-pulse hidden md:block"><Edit3 size={18} /></div>
                        <div>
                            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">Mode Édition <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 text-[10px] rounded-full">Live Simulation</span></h2>
                            {/* KPI LIVE RECAP */}
                            <div className="flex items-center gap-4 mt-1 text-[10px] font-mono text-slate-400">
                                <span className="flex items-center gap-1"><Eye size={10}/> {(editorMetrics.imp/1000).toFixed(1)}k Imp</span>
                                <span className="flex items-center gap-1"><MousePointerClick size={10}/> {editorMetrics.clicks} Clics</span>
                                <span className="flex items-center gap-1 text-emerald-400"><Target size={10}/> {editorMetrics.leads} Leads</span>
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-3 w-full md:w-auto justify-end">
                         <div className="hidden md:flex flex-col items-end mr-4 border-r border-slate-700 pr-4">
                             <span className="text-[10px] text-slate-500 uppercase font-bold">Total Budget Net</span>
                             <span className="text-lg font-mono font-bold text-emerald-400">
                                 {editData.insertions.reduce((acc: number, i: any) => acc + (i.coutEstime || 0), 0).toLocaleString()} MAD
                             </span>
                         </div>
                         <button onClick={() => setIsEditing(false)} className="h-9 px-4 rounded-lg text-xs font-bold text-slate-400 hover:bg-slate-800 transition-colors border border-transparent hover:border-slate-700">Annuler</button>
                         <button onClick={handleSaveEdit} disabled={isSaving} className="h-9 px-6 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-500/20 hover:scale-105 active:scale-95">
                             {isSaving ? <Loader2 size={14} className="animate-spin"/> : <Save size={14} />} 
                             {isSaving ? 'Sauvegarde...' : 'Valider'}
                         </button>
                    </div>
                </div>

                {/* FORMULAIRE GLOBAL */}
                <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        {/* Bloc Nom */}
                        <div className="bg-[#1E293B] p-4 rounded-xl border border-slate-700/50">
                            <label className="block text-[10px] text-indigo-400 uppercase font-bold mb-2">Nom de la Campagne</label>
                            <input type="text" value={editData.plan.nomPlan || ''} onChange={(e) => handleEditChange('plan.nomPlan', e.target.value)} className="w-full bg-[#0F172A] border border-slate-700 rounded-lg px-3 py-2 text-sm font-bold text-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all" />
                        </div>
                        
                        {/* Bloc Statut */}
                        <div className="bg-[#1E293B] p-4 rounded-xl border border-slate-700/50">
                             <label className="block text-[10px] text-indigo-400 uppercase font-bold mb-2">Statut</label>
                             <StatusDropdown currentStatus={editData.plan.status || 'Brouillon'} onChange={(val) => handleEditChange('plan.status', val)} />
                        </div>

                        {/* Bloc Frais & Commissions */}
                        <div className="bg-[#1E293B] p-4 rounded-xl border border-slate-700/50 col-span-2">
                             <div className="flex items-center justify-between mb-2">
                                <label className="block text-[10px] text-indigo-400 uppercase font-bold">Frais & Commissions</label>
                             </div>
                             <div className="flex items-center gap-4">
                                {/* Commission */}
                                <div className={`flex-1 flex items-center gap-2 p-2 rounded border ${editData.plan.showCommission !== false ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-slate-700 bg-slate-800/50'}`}>
                                    <button onClick={() => handleEditChange('plan.showCommission', !(editData.plan.showCommission !== false))} className={`text-xs ${editData.plan.showCommission !== false ? 'text-emerald-400' : 'text-slate-500'}`}>
                                        {editData.plan.showCommission !== false ? <ToggleRight size={20}/> : <ToggleLeft size={20}/>}
                                    </button>
                                    <div className="flex flex-col">
                                        <span className="text-[9px] uppercase font-bold text-slate-500">Comm. Agence</span>
                                        <div className="flex items-center gap-1">
                                            <input type="number" value={editData.plan.commissionRate ?? 15} onChange={(e) => handleEditChange('plan.commissionRate', e.target.value)} disabled={editData.plan.showCommission === false} className="w-12 bg-transparent text-sm font-bold text-white text-right outline-none border-b border-slate-600 focus:border-emerald-500" />
                                            <span className="text-xs text-slate-500">%</span>
                                        </div>
                                    </div>
                                </div>
                                {/* Fees */}
                                <div className={`flex-1 flex items-center gap-2 p-2 rounded border ${editData.plan.showFees !== false ? 'border-amber-500/30 bg-amber-500/5' : 'border-slate-700 bg-slate-800/50'}`}>
                                    <button onClick={() => handleEditChange('plan.showFees', !(editData.plan.showFees !== false))} className={`text-xs ${editData.plan.showFees !== false ? 'text-amber-400' : 'text-slate-500'}`}>
                                        {editData.plan.showFees !== false ? <ToggleRight size={20}/> : <ToggleLeft size={20}/>}
                                    </button>
                                    <div className="flex flex-col">
                                        <span className="text-[9px] uppercase font-bold text-slate-500">Frais Tech.</span>
                                        <div className="flex items-center gap-1">
                                            <input type="number" value={editData.plan.feesRate ?? 0} onChange={(e) => handleEditChange('plan.feesRate', e.target.value)} disabled={editData.plan.showFees === false} className="w-12 bg-transparent text-sm font-bold text-white text-right outline-none border-b border-slate-600 focus:border-amber-500" />
                                            <span className="text-xs text-slate-500">%</span>
                                        </div>
                                    </div>
                                </div>
                             </div>
                        </div>

                         {/* --- NOUVEAU BLOC: BENCHMARKS DE PERFORMANCE --- */}
                         <div className="bg-[#1E293B] p-4 rounded-xl border border-slate-700/50 col-span-4">
                             <div className="flex items-center justify-between mb-3 border-b border-slate-700 pb-2">
                                <label className="text-[10px] text-indigo-400 uppercase font-bold flex items-center gap-2"><BarChart4 size={12}/> Benchmarks de Performance (Estimations)</label>
                                <span className="text-[9px] text-slate-500 uppercase tracking-widest">Valeurs en %</span>
                             </div>
                             <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="bg-[#0F172A] p-2 rounded border border-slate-700 flex flex-col">
                                    <span className="text-[9px] text-slate-500 uppercase font-bold mb-1">CTR Display</span>
                                    <div className="flex items-center gap-1">
                                        <input type="number" step="0.1" value={editData.plan.ctrDisplay ?? DEFAULT_BENCHMARKS.CTR_DISPLAY} onChange={(e) => handleEditChange('plan.ctrDisplay', e.target.value)} className="w-full bg-transparent text-sm font-mono font-bold text-indigo-300 outline-none" />
                                        <span className="text-[10px] text-slate-600">%</span>
                                    </div>
                                </div>
                                <div className="bg-[#0F172A] p-2 rounded border border-slate-700 flex flex-col">
                                    <span className="text-[9px] text-slate-500 uppercase font-bold mb-1">CTR Search</span>
                                    <div className="flex items-center gap-1">
                                        <input type="number" step="0.1" value={editData.plan.ctrSearch ?? DEFAULT_BENCHMARKS.CTR_SEARCH} onChange={(e) => handleEditChange('plan.ctrSearch', e.target.value)} className="w-full bg-transparent text-sm font-mono font-bold text-blue-300 outline-none" />
                                        <span className="text-[10px] text-slate-600">%</span>
                                    </div>
                                </div>
                                <div className="bg-[#0F172A] p-2 rounded border border-slate-700 flex flex-col">
                                    <span className="text-[9px] text-slate-500 uppercase font-bold mb-1">VTR Vidéo</span>
                                    <div className="flex items-center gap-1">
                                        <input type="number" step="1" value={editData.plan.vtrVideo ?? DEFAULT_BENCHMARKS.VTR_VIDEO} onChange={(e) => handleEditChange('plan.vtrVideo', e.target.value)} className="w-full bg-transparent text-sm font-mono font-bold text-pink-300 outline-none" />
                                        <span className="text-[10px] text-slate-600">%</span>
                                    </div>
                                </div>
                                <div className="bg-[#0F172A] p-2 rounded border border-slate-700 flex flex-col">
                                    <span className="text-[9px] text-slate-500 uppercase font-bold mb-1">Taux Conv. (Moy.)</span>
                                    <div className="flex items-center gap-1">
                                        <input type="number" step="0.1" value={editData.plan.convRate ?? DEFAULT_BENCHMARKS.CONV_RATE} onChange={(e) => handleEditChange('plan.convRate', e.target.value)} className="w-full bg-transparent text-sm font-mono font-bold text-emerald-300 outline-none" />
                                        <span className="text-[10px] text-slate-600">%</span>
                                    </div>
                                </div>
                             </div>
                        </div>

                    </div>

                    {/* TABLEAU ÉDITABLE */}
                    <div className="bg-[#1E293B] border border-slate-700 rounded-xl overflow-hidden shadow-xl">
                        <div className="px-6 py-4 border-b border-slate-700 bg-[#1E293B] flex justify-between items-center">
                            <h3 className="font-bold text-sm text-white flex items-center gap-2"><Layers size={16} className="text-indigo-500"/> Insertions & Budgets</h3>
                            <button className="text-[10px] bg-indigo-600/20 text-indigo-400 px-2 py-1 rounded hover:bg-indigo-600 hover:text-white transition-colors">+ Ajouter Ligne</button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-xs text-left border-collapse">
                                <thead className="bg-[#0F172A] text-slate-400 uppercase font-bold text-[10px]">
                                    <tr>
                                        <th className="px-4 py-3 border-b border-slate-700 w-1/5">Canal / Support</th>
                                        <th className="px-4 py-3 border-b border-slate-700">Format</th>
                                        <th className="px-4 py-3 border-b border-slate-700 w-1/4">Ciblage / Audience</th>
                                        <th className="px-4 py-3 border-b border-slate-700">Modèle</th>
                                        <th className="px-4 py-3 border-b border-slate-700 text-right">Volume</th>
                                        <th className="px-4 py-3 border-b border-slate-700 text-right">C.U.</th>
                                        <th className="px-4 py-3 border-b border-slate-700 text-right w-28">Budget</th>
                                        <th className="px-2 py-3 border-b border-slate-700 w-10"></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-700/50">
                                    {editData.insertions.map((ins: any) => (
                                        <tr key={ins.id} className="hover:bg-indigo-500/5 transition-colors group">
                                            <td className="p-2">
                                                <input type="text" value={ins.canal || ''} onChange={(e) => handleEditChange(`insertion.canal`, e.target.value, ins.id)} 
                                                    className="w-full bg-transparent border border-transparent hover:border-slate-600 focus:border-indigo-500 rounded px-2 py-1.5 text-white font-medium focus:bg-[#0F172A] outline-none transition-all placeholder-slate-600" placeholder="Ex: Facebook" />
                                            </td>
                                            <td className="p-2">
                                                <input type="text" value={ins.format || ''} onChange={(e) => handleEditChange(`insertion.format`, e.target.value, ins.id)} 
                                                    className="w-full bg-transparent border border-transparent hover:border-slate-600 focus:border-indigo-500 rounded px-2 py-1.5 text-slate-300 focus:bg-[#0F172A] outline-none" placeholder="Ex: Story" />
                                            </td>
                                            <td className="p-2">
                                                <input type="text" value={ins.targeting || ''} onChange={(e) => handleEditChange(`insertion.ciblage`, e.target.value, ins.id)} 
                                                    className="w-full bg-transparent border border-transparent hover:border-slate-600 focus:border-indigo-500 rounded px-2 py-1.5 text-xs text-slate-400 focus:bg-[#0F172A] outline-none" placeholder="Ex: 25-45 ans, urbain" />
                                            </td>
                                            <td className="p-2">
                                                <select value={ins.modeleAchat || 'CPM'} onChange={(e) => handleEditChange(`insertion.modele`, e.target.value, ins.id)}
                                                    className="w-full bg-transparent border border-transparent hover:border-slate-600 focus:border-indigo-500 rounded px-2 py-1.5 text-slate-300 focus:bg-[#0F172A] outline-none cursor-pointer">
                                                    <option value="CPM">CPM</option><option value="CPC">CPC</option><option value="CPV">CPV</option><option value="CPL">CPL</option><option value="FLAT">Forfait</option>
                                                </select>
                                            </td>
                                            <td className="p-2">
                                                <input type="number" value={ins.quantiteAchetee || 0} onChange={(e) => handleEditChange(`insertion.volume`, e.target.value, ins.id)} 
                                                    className="w-full bg-transparent border border-transparent hover:border-slate-600 focus:border-indigo-500 rounded px-2 py-1.5 text-right font-mono text-slate-300 focus:bg-[#0F172A] outline-none" />
                                            </td>
                                            <td className="p-2">
                                                <div className="text-right font-mono text-slate-500 px-2 py-1.5 text-xs">{ins.coutUnitaire ? ins.coutUnitaire.toFixed(2) : '-'}</div>
                                            </td>
                                            <td className="p-2">
                                                <input type="number" value={ins.coutEstime || 0} onChange={(e) => handleEditChange(`insertion.budget`, e.target.value, ins.id)} 
                                                    className="w-full bg-indigo-500/10 border border-indigo-500/30 focus:border-indigo-500 rounded px-2 py-1.5 text-right font-mono font-bold text-indigo-400 focus:bg-[#0F172A] outline-none" />
                                            </td>
                                            <td className="p-2 text-center">
                                                 <button className="text-slate-600 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100 p-1"><Trash2 size={14}/></button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {editData.insertions.length === 0 && <div className="p-8 text-center text-slate-500 text-sm">Aucune insertion. Commencez par en ajouter une.</div>}
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <StudioLayout
            leftContent={renderSidebar}
            rightContent={
                <div className="flex flex-col h-full bg-[#0F172A]">
                    {/* Header Principal (Visible en mode Lecture) */}
                    {!isEditing && (
                        <div className="h-16 border-b border-slate-800 bg-[#0F172A] flex items-center justify-between px-6 flex-shrink-0 z-40">
                            <div className="flex items-center gap-6">
                                <Link href="/" className="flex items-center justify-center p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors border border-slate-700/50"><Home size={20} /></Link>
                                <div className="flex items-center gap-3">
                                    {activeTheme?.iconeUrl ? <img src={activeTheme.iconeUrl} alt="Agence" className="w-10 h-10 object-contain rounded-lg p-1 bg-slate-800" /> : <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-violet-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">5B</div>}
                                    <div><div className="text-white font-bold leading-none tracking-tight">SANDBOX Studio</div><div className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Media Intelligence</div></div>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                {/* Theme Switcher */}
                                <div className="relative group">
                                    <button className="h-9 px-3 rounded-lg text-xs font-bold text-slate-400 hover:bg-slate-800 hover:text-white transition-colors flex items-center gap-2 border border-transparent hover:border-slate-700"><Palette size={14} /><span className="hidden md:inline">Thème: {activeTheme?.name.split('(')[0].trim()}</span><ChevronDown size={12} /></button>
                                    <div className="absolute right-0 top-full mt-2 w-56 bg-[#1E293B] border border-slate-700 rounded-xl shadow-2xl opacity-0 group-hover:opacity-100 invisible group-hover:visible transition-all z-50 p-2 space-y-1">
                                        {design?.themes.map(theme => (
                                            <button key={theme.id} onClick={() => setLocalThemeId(theme.id)} className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${theme.id === activeTheme?.id ? 'bg-indigo-500/10 text-indigo-400 font-bold' : 'text-slate-300'}`}><span>{theme.name.split('(')[0].trim()}</span>{theme.id === activeTheme?.id && <Check size={12} />}</button>
                                        ))}
                                    </div>
                                </div>
                                {planId && rawPlanData ? (
                                    <>
                                        <button onClick={handleEditToggle} className="h-9 px-4 rounded-lg text-xs font-bold text-indigo-400 hover:bg-indigo-500/10 border border-indigo-500/20 hover:border-indigo-500/50 transition-all flex items-center gap-2 shadow-lg shadow-indigo-900/20"><Edit3 size={14} /> Modifier</button>
                                        <button onClick={handlePublish} disabled={isPublishing} className={`h-9 px-5 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center gap-2 ${isPublishing ? 'bg-slate-800 text-slate-500 cursor-wait' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20'}`}>{isPublishing ? <Loader2 size={12} className="animate-spin"/> : <Share2 size={12} />} {isPublishing ? 'Publication...' : 'Publier'}</button>
                                    </>
                                ) : (<div className="text-xs text-slate-600 italic px-4">Prêt</div>)}
                            </div>
                        </div>
                    )}

                    <div className="flex-1 overflow-hidden relative">
                        {isEditing ? renderEditor() : <DashboardRenderer code={currentCode} rawPlanData={rawPlanData} />}
                    </div>

                    {publishModalOpen && (
                        <div className="absolute inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in">
                            <div className="bg-[#1E293B] border border-slate-700 rounded-2xl shadow-2xl w-full max-w-md p-6 relative">
                                <div className="flex justify-between items-start mb-6"><div className="flex items-center gap-4"><div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30"><Check size={24} strokeWidth={3} /></div><div><h3 className="text-xl font-bold text-white">Plan Publié !</h3><p className="text-sm text-slate-400">Votre rapport est en ligne.</p></div></div><button onClick={() => setPublishModalOpen(false)} className="text-slate-500 hover:text-white"><X size={20} /></button></div>
                                <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 flex items-center gap-3 mb-8"><Globe size={16} className="text-slate-500" /><div className="flex-1 font-mono text-xs text-slate-400 truncate select-all">{lastPublishedUrl}</div><button onClick={() => navigator.clipboard.writeText(lastPublishedUrl || '')} className="text-indigo-400 hover:text-white p-2 hover:bg-slate-800 rounded-lg"><Copy size={16} /></button></div>
                                <div className="grid grid-cols-2 gap-4"><button onClick={() => setPublishModalOpen(false)} className="py-3 text-sm font-bold text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl border border-slate-700">Fermer</button><a href={lastPublishedUrl || '#'} target="_blank" className="py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold rounded-xl flex items-center justify-center gap-2">Voir <ExternalLink size={16} /></a></div>
                            </div>
                        </div>
                    )}
                </div>
            }
            bottomContent={
                <div className="h-9 bg-[#020617] border-t border-slate-800 flex items-center justify-between px-6 text-[10px] text-slate-500 flex-shrink-0 z-50 select-none">
                    <div className="flex items-center gap-4"><span className="font-bold text-slate-400 tracking-wider">SANDBOX STUDIO v2.2</span><span className="w-px h-3 bg-slate-800"></span><span className="flex items-center gap-2"><div className={`w-1 h-1 rounded-full ${isEditing ? 'bg-amber-500 animate-bounce' : 'bg-emerald-500'} `}></div>{isEditing ? 'MODE ÉDITION ACTIF' : 'SYSTÈME OPÉRATIONNEL'}</span></div>
                    <div className="flex items-center gap-6"><div className="flex items-center gap-2"><Database size={10} className="text-indigo-500" /><span>DB: <strong className="text-slate-400">{MEDIA_PLANS_COLLECTION}</strong></span></div><SystemClock /></div>
                </div>
            } 
        />
    );
}