'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { 
  Database, Loader2, Search, Filter, Home, TrendingUp, DollarSign, Target, Briefcase, ChevronDown, Check, RotateCcw, Zap, Calendar, Layout, Tag
} from 'lucide-react'; // Ajout des icônes manquantes pour le code React Live

// UI
import StudioLayout from "../../components/StudioLayout";
import DashboardRenderer from "../../components/DashboardRenderer"; 

// Firebase
import { 
    db, 
    authenticateUser, 
    MEDIA_PLANS_COLLECTION, 
    INSERTIONS_COLLECTION, 
    ANNONCEURS_COLLECTION, 
    BUYING_MODELS_COLLECTION, // Pour les filtres
    CANAUX_COLLECTION,       // Pour les graphiques
    AGENCE_SETTINGS_COLLECTION // Pour les logos (si besoin) // CORRIGÉ: Import désormais disponible
} from '../../lib/firebase'; 
import { collection, getDocs, onSnapshot, query, DocumentData } from 'firebase/firestore'; // Import de DocumentData

// --- TYPES ---

interface InsertionData extends DocumentData {
    id: string;
    planRef: string;
    canal: string;
    modeleAchat: string;
    coutEstime: number; // Budget Net
}

interface PlanData extends DocumentData {
    id: string;
    nomPlan: string;
    annonceurRef: string;
    budgetTotal: number;
    objectifPrincipal: string;
}

interface AnnonceurData extends DocumentData {
    id: string;
    nomAnnonceur: string;
}

interface ReferenceData {
    id: string;
    name: string;
}

interface AggregatedBreakdown {
    canal: { name: string, value: number, fill: string }[];
    modele: { name: string, value: number, fill: string }[];
    annonceur: { name: string, value: number, totalPlans: number }[];
}

interface GlobalMediaData {
    plans: PlanData[];
    insertions: InsertionData[];
    annonceurs: AnnonceurData[];
    canaux: ReferenceData[];
    models: ReferenceData[];
}


// --- DATA HOOK GLOBAL (Chargement et Aggregation) ---
function useGlobalMediaData() {
    const [data, setData] = useState<GlobalMediaData | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchAllData = async () => {
            setLoading(true);
            setError(null);
            
            try {
                await authenticateUser();

                // On récupère tout en une fois
                const [plansSnap, insertionsSnap, annonceursSnap, canauxSnap, modelsSnap] = await Promise.all([
                    getDocs(collection(db, MEDIA_PLANS_COLLECTION)),
                    getDocs(collection(db, INSERTIONS_COLLECTION)),
                    getDocs(collection(db, ANNONCEURS_COLLECTION)),
                    getDocs(collection(db, CANAUX_COLLECTION)),
                    getDocs(collection(db, BUYING_MODELS_COLLECTION)),
                ]);

                // CORRIGÉ: S'assurer que les données extraites correspondent aux interfaces
                const plans = plansSnap.docs.map(d => ({ id: d.id, ...d.data() } as PlanData));
                const insertions = insertionsSnap.docs.map(d => ({ id: d.id, ...d.data() } as InsertionData));
                const annonceurs = annonceursSnap.docs.map(d => ({ id: d.id, ...d.data() } as AnnonceurData));
                const canaux = canauxSnap.docs.map(d => ({ id: d.id, ...d.data() } as ReferenceData));
                const models = modelsSnap.docs.map(d => ({ id: d.id, ...d.data() } as ReferenceData));

                setData({ plans, insertions, annonceurs, canaux, models });

            } catch (err: any) {
                console.error("Erreur de chargement global BDD:", err);
                setError("Erreur de connexion aux collections. Vérifiez les règles de sécurité.");
            } finally {
                setLoading(false);
            }
        };

        fetchAllData();
    }, []);

    return { data, loading, error };
}


// --- LOGIQUE METIER ET FILTRES ---

function useFilteredData(data: GlobalMediaData | null) {
    const [filters, setFilters] = useState({
        annonceurId: 'all',
        modeleAchatId: 'all',
    });

    // Aggrégation et jointures
    const aggregatedData = useMemo(() => {
        if (!data) return { 
            totalBudget: 0, 
            plans: [], 
            filteredInsertions: [],
            breakdowns: { canal: [], modele: [], annonceur: [] } as AggregatedBreakdown
        };
        
        // CORRIGÉ: Définir le type PlanWithAnnName pour la Map
        type PlanWithAnnName = PlanData & { nomAnnonceur: string };
        
        // 1. Jointure Plans <-> Annonceurs
        const plansMap = new Map<string, PlanWithAnnName>(
            data.plans.map((p: PlanData) => [p.id, { 
                ...p, 
                nomAnnonceur: data.annonceurs.find((a: AnnonceurData) => a.id === p.annonceurRef)?.nomAnnonceur || p.annonceurRef 
            }])
        );

        // 2. Filtrage des Insertions
        const filteredInsertions = data.insertions.filter((ins: InsertionData) => {
            const plan = plansMap.get(ins.planRef);
            // CORRIGÉ: S'assurer que plan existe et qu'annonceurRef existe sur le plan original
            if (!plan) return false; 

            const matchesAnnonceur = filters.annonceurId === 'all' || plan.annonceurRef === filters.annonceurId;
            const matchesModele = filters.modeleAchatId === 'all' || ins.modeleAchat === filters.modeleAchatId;

            return matchesAnnonceur && matchesModele;
        });

        // 3. Calculs Agrégés
        const totalBudget = filteredInsertions.reduce((sum: number, ins: InsertionData) => sum + (ins.coutEstime || 0), 0); // CORRIGÉ: typage des paramètres

        // 4. Breakdowns (Ventilation)
        const breakdowns = filteredInsertions.reduce((acc: AggregatedBreakdown, ins: InsertionData) => { // CORRIGÉ: typage des paramètres
            const plan = plansMap.get(ins.planRef);
            const budget = ins.coutEstime || 0;
            if (!plan) return acc; // S'assurer que le plan est joint

            // Ventilation par Canal
            const canalRef = data.canaux.find((c: ReferenceData) => c.id === ins.canal)?.name || ins.canal || 'Autre'; // CORRIGÉ: typage des paramètres
            const existingCanal = acc.canal.find((item: { name: string }) => item.name === canalRef); // CORRIGÉ: typage des paramètres
            if (existingCanal) existingCanal.value += budget;
            else acc.canal.push({ name: canalRef, value: budget, fill: '#6366f1' }); // Couleur par défaut

            // Ventilation par Modèle d'Achat
            const modeleRef = data.models.find((m: ReferenceData) => m.id === ins.modeleAchat)?.name || ins.modeleAchat || 'Autre'; // CORRIGÉ: typage des paramètres
            const existingModele = acc.modele.find((item: { name: string }) => item.name === modeleRef); // CORRIGÉ: typage des paramètres
            if (existingModele) existingModele.value += budget;
            else acc.modele.push({ name: modeleRef, value: budget, fill: '#10b981' }); 
            
            // Ventilation par Annonceur (pour le tableau)
            const annonceurRef = plan.nomAnnonceur || 'Inconnu'; // CORRIGÉ: utilise le plan joint
            const existingAnnonceur = acc.annonceur.find((item: { name: string }) => item.name === annonceurRef); // CORRIGÉ: typage des paramètres
            if (existingAnnonceur) {
                existingAnnonceur.value += budget;
            } else {
                 acc.annonceur.push({ name: annonceurRef, value: budget, totalPlans: 1 });
            }

            // CORRIGÉ: Mise à jour du totalPlans (besoin de l'ID du plan pour le faire correctement, mais pour la démo on peut ignorer car c'est un breakdown d'insertion)
            // Pour l'instant, totalPlans n'est pas utilisé dans le tableau, on peut simplifier en comptant 1 par ligne pour la démo.

            return acc;
        }, { canal: [], modele: [], annonceur: [] } as AggregatedBreakdown); // CORRIGÉ: Initialisation avec le bon type

        // On trie les breakdowns (les plus gros en premier)
        breakdowns.canal.sort((a,b) => b.value - a.value);
        breakdowns.modele.sort((a,b) => b.value - a.value);
        breakdowns.annonceur.sort((a,b) => b.value - a.value);


        return {
            totalBudget,
            plans: data.plans, 
            filteredInsertions,
            breakdowns,
        };
    }, [data, filters]);

    // Liste des filtres disponibles pour l'UI
    const filterOptions = useMemo(() => {
        if (!data) return { annonceurs: [], modeles: [], canaux: [], models: [] }; // CORRIGÉ: Ajout de modèles/canaux à l'interface

        const annOptions = data.annonceurs.map((a: AnnonceurData) => ({ id: a.id, name: a.nomAnnonceur })); // CORRIGÉ: typage des paramètres
        const modelOptions = data.models.map((m: ReferenceData) => ({ id: m.id, name: m.name })); // CORRIGÉ: typage des paramètres
        
        return {
            annonceurs: annOptions,
            modeles: modelOptions,
            canaux: data.canaux, // Ajout pour la sidebar
            models: data.models,
        };
    }, [data]);

    return { 
        aggregatedData, 
        filters, 
        setFilters, 
        filterOptions 
    };
}


// --- CODE REACT LIVE POUR LE RENDU DU DASHBOARD AGRÉGÉ ---
const PORTFOLIO_DASHBOARD_CODE = (
// Le code est injecté comme une fonction qui reçoit les données agrégées
`const { totalBudget, breakdowns, filterOptions, filters, setFilters, plans } = rawPlanData;

// Composant de sélection (pour les filtres)
const FilterSelect = ({ options, currentId, onChange, icon: Icon, label }) => {
    // Jointure pour obtenir le nom complet du filtre sélectionné
    const currentName = options.find(o => o.id === currentId)?.name || 'Tous';
    
    return (
        <div className="relative w-full">
            <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">{label}</label>
            <div className="relative group/input">
                <Icon size={16} className="absolute left-3 top-3 text-slate-500"/>
                <select
                    value={currentId}
                    onChange={(e) => onChange(e.target.value)}
                    className="w-full bg-[#0F172A] border border-slate-700 rounded-xl py-2 pl-10 pr-10 text-sm text-slate-200 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none appearance-none transition-all cursor-pointer"
                >
                    <option value="all">Tous les \${label.toLowerCase()}</option>
                    {options.map(opt => (
                        <option key={opt.id} value={opt.id}>{opt.name}</option>
                    ))}
                </select>
                <ChevronDown size={16} className="absolute right-3 top-3 text-slate-500 pointer-events-none" />
            </div>
        </div>
    );
};

// COMPOSANT PRINCIPAL
const PortfolioDashboard = () => {
    // Couleurs par défaut pour les graphiques
    const CANAL_COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06B6D4', '#EC4899'];
    const MODELE_COLORS = ['#06B6D4', '#F472B6', '#FBBF24', '#34D399', '#A78BFA', '#1D4ED8'];

    // Calcul des KPIS primaires
    const totalPlans = plans.length;
    
    // Simuler le budget en cours vs Planifié (pour la démo)
    const budgetPlanifie = plans.reduce((acc, p) => acc + (p.budgetTotal || 0), 0);
    const budgetEnCours = totalBudget; // Budget des insertions chargées
    const tauxExecution = budgetPlanifie > 0 ? (budgetEnCours / budgetPlanifie) * 100 : 0;
    
    // Trouver le plan le plus cher
    const topPlan = plans.sort((a, b) => b.budgetTotal - a.budgetTotal)[0];


    const kpis = [
      { label: "Budget Net Média Filtré", val: totalBudget.toLocaleString('fr-FR', { maximumFractionDigits: 0 }), unit: "MAD", icon: Lucide.DollarSign, color: "text-violet-400" },
      { label: "Budget Total Planifié", val: budgetPlanifie.toLocaleString('fr-FR', { maximumFractionDigits: 0 }), unit: "MAD", icon: Lucide.Calendar, color: "text-slate-200" },
      { label: "Taux d'Exécution", val: tauxExecution.toFixed(1), unit: "%", icon: Lucide.Zap, color: tauxExecution > 80 ? "text-emerald-400" : "text-amber-400" },
      { label: "Nombre de Plans Actifs", val: totalPlans, unit: "", icon: Lucide.Layout, color: "text-indigo-400" },
    ];
    
    // Affichage si les filtres sont appliqués
    const isFiltered = filters.annonceurId !== 'all' || filters.modeleAchatId !== 'all';
    
    // Affichage des données
    const dataCanal = breakdowns.canal.map((item, index) => ({
        ...item,
        fill: CANAL_COLORS[index % CANAL_COLORS.length]
    }));
    const dataModele = breakdowns.modele.map((item, index) => ({
        ...item,
        fill: MODELE_COLORS[index % MODELE_COLORS.length]
    }));

    return (
      <div className="min-h-full bg-[#0F172A] font-sans text-slate-100 pb-12 selection:bg-violet-500/30">
        
        {/* HEADER */}
        <div className="bg-[#1E293B]/30 border-b border-slate-800/50 px-8 py-8">
          <div className="max-w-7xl mx-auto">
             <div className="flex items-center gap-4 mb-3">
                 <div className="p-2 bg-violet-500/10 rounded-lg border border-violet-500/20">
                    <Lucide.TrendingUp size={24} className="text-violet-500" />
                 </div>
                 <h1 className="text-3xl font-bold text-white tracking-tight">Portefeuille Média Agence</h1>
              </div>
              <p className="text-slate-400 text-sm max-w-2xl">
                Vue consolidée stratégique pour la direction Digital Media. Analysez la répartition des investissements par client, canal et modèle d'achat.
              </p>
          </div>
        </div>

        <div className="px-8 py-8 max-w-7xl mx-auto space-y-8">
          
          {/* SECTION FILTRES */}
          <div className="bg-[#1E293B] p-6 rounded-xl border border-slate-800 shadow-lg">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                <FilterSelect 
                    options={filterOptions.annonceurs} 
                    currentId={filters.annonceurId} 
                    onChange={(id) => setFilters(prev => ({ ...prev, annonceurId: id }))}
                    icon={Lucide.Briefcase}
                    label="Filtrer par Annonceur"
                />

                <FilterSelect 
                    options={filterOptions.modeles} 
                    currentId={filters.modeleAchatId} 
                    onChange={(id) => setFilters(prev => ({ ...prev, modeleAchatId: id }))}
                    icon={Lucide.Tag}
                    label="Filtrer par Modèle d'Achat"
                />

                {/* Bouton de Reset */}
                <div className="pt-6">
                    <button 
                        onClick={() => setFilters({ annonceurId: 'all', modeleAchatId: 'all' })}
                        disabled={!isFiltered}
                        className={\`w-full h-12 rounded-xl text-xs font-bold uppercase tracking-wide transition-all flex items-center justify-center gap-2 border border-slate-700 \${isFiltered ? 'bg-slate-800 text-slate-300 hover:bg-slate-700' : 'bg-slate-900 text-slate-600 cursor-not-allowed'}\`}
                    >
                        <Lucide.RotateCcw size={14} /> Réinitialiser les Filtres
                    </button>
                </div>
             </div>
             {isFiltered && (
                 <div className="mt-4 p-3 bg-violet-500/10 border border-violet-500/30 rounded-lg flex items-center gap-2 text-xs text-violet-300 font-medium">
                     <Check size={14} className="text-violet-400" />
                     Analyse filtrée : Seul le budget correspondant aux critères est affiché.
                 </div>
             )}
          </div>
          
          {/* KPIS (Mis à jour selon le filtre) */}
          <div className={\`grid grid-cols-1 md:grid-cols-4 gap-6\`}>
             {kpis.map((kpi, i) => (
               <div key={i} className="bg-[#1E293B] p-5 rounded-xl border border-slate-800 shadow-lg relative overflow-hidden group">
                  <div className="flex justify-between items-start mb-2">
                     <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{kpi.label}</span>
                     <kpi.icon size={16} className={\`\${kpi.color} opacity-80\`} />
                  </div>
                  <div className="text-2xl font-bold text-white font-mono">
                     {kpi.val} <span className="text-sm font-normal text-slate-500">{kpi.unit}</span>
                  </div>
               </div>
             ))}
          </div>

          {/* GRAPHIQUES & BREAKDOWN */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[400px]">
             
             {/* Graphique 1 : Ventilation par Canal */}
             <div className="bg-[#1E293B] rounded-xl border border-slate-800 p-6 flex flex-col shadow-lg">
                <h3 className="font-bold text-slate-200 mb-4 text-xs uppercase tracking-widest flex items-center gap-2">
                   <IconPieChart size={14} className="text-violet-500"/> Ventilation par Canal
                </h3>
                <div className="flex-1 w-full min-h-[250px]">
                   <ResponsiveContainer width="100%" height="100%">
                     <PieChart>
                       <Pie data={dataCanal} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value" stroke="none">
                         {dataCanal.map((entry, index) => <Cell key={'cell-canal-' + index} fill={CANAL_COLORS[index % CANAL_COLORS.length]} />)}
                       </Pie>
                       <Tooltip 
                          contentStyle={{borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#0F172A', color: '#fff'}}
                          formatter={(val, name, props) => [\`\${val.toLocaleString('fr-FR', { maximumFractionDigits: 0 })} MAD (\${((val / totalBudget) * 100).toFixed(1)}%)\`, name]}
                       />
                       <Legend verticalAlign="bottom" iconType="circle" wrapperStyle={{fontSize: '10px', color: '#94a3b8'}} />
                     </PieChart>
                   </ResponsiveContainer>
                </div>
             </div>

             {/* Graphique 2 : Ventilation par Modèle d'Achat */}
             <div className="bg-[#1E293B] rounded-xl border border-slate-800 p-6 flex flex-col shadow-lg">
                <h3 className="font-bold text-slate-200 mb-4 text-xs uppercase tracking-widest flex items-center gap-2">
                   <IconBarChart size={14} className="text-emerald-500"/> Répartition par Modèle d'Achat
                </h3>
                <div className="flex-1 w-full min-h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={dataModele} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
                            <XAxis type="number" stroke="#94A3B8" fontSize={12} tickFormatter={(value) => \`\${value / 1000}k\`} />
                            <YAxis type="category" dataKey="name" stroke="#94A3B8" fontSize={12} tickLine={false} axisLine={false} width={80} />
                            <Tooltip 
                                contentStyle={{borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#0F172A', color: '#fff'}}
                                formatter={(val) => \`\${val.toLocaleString('fr-FR', { maximumFractionDigits: 0 })} MAD\`}
                            />
                            <Bar dataKey="value" fill="#8884d8" radius={[10, 10, 10, 10]}>
                                {dataModele.map((entry, index) => <Cell key={\`cell-modele-\${index}\`} fill={MODELE_COLORS[index % MODELE_COLORS.length]} />)}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
             </div>
          </div>
          
          {/* TABLEAU: Annonceurs Contributifs */}
          <div className="bg-[#1E293B] rounded-xl border border-slate-800 flex flex-col overflow-hidden shadow-lg mt-8">
             <div className="px-6 py-4 border-b border-slate-800 bg-[#1E293B] flex justify-between items-center">
                   <h3 className="font-bold text-white text-sm flex items-center gap-2">
                      <Lucide.Briefcase size={16} className="text-violet-500"/>
                      Top 10 Annonceurs (Budget)
                   </h3>
                   <span className="text-[10px] text-slate-500">Affiche la contribution au budget total agrégé.</span>
             </div>
             <div className="flex-1 overflow-x-auto">
                   <table className="w-full text-xs text-left">
                     <thead className="text-[10px] text-slate-400 uppercase font-bold bg-[#0F172A] border-b border-slate-700">
                       <tr>
                         <th className="px-4 py-3 pl-6 w-1/2">Annonceur</th>
                         <th className="px-4 py-3 text-right">Budget Agrégé Net</th>
                         <th className="px-4 py-3 text-right pr-6">% du Total Filtré</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-800">
                       {breakdowns.annonceur.slice(0, 10).map((ann, i) => {
                         const part = totalBudget > 0 ? (ann.value / totalBudget) * 100 : 0;
                         return (
                         <tr key={i} className="hover:bg-violet-500/5 transition-colors group">
                           <td className="px-4 py-3 pl-6">
                             <div className="font-bold text-slate-200">{ann.name}</div>
                             <div className="text-[10px] text-slate-500 italic">Total Plans: {ann.totalPlans}</div>
                           </td>
                           <td className="px-4 py-3 text-right font-bold text-violet-400 font-mono">
                              {ann.value.toLocaleString('fr-FR', { maximumFractionDigits: 0 })} MAD
                           </td>
                           <td className="px-4 py-3 text-right pr-6 text-slate-400 font-mono">
                              {part.toFixed(1)}%
                           </td>
                         </tr>
                       )})}
                     </tbody>
                   </table>
             </div>
          </div>
          
        </div>
      </div>
    );
};

render(<PortfolioDashboard />);
`
);


export default function PortefeuillePage() {
    const { data, loading, error } = useGlobalMediaData();
    const { aggregatedData, filters, setFilters, filterOptions } = useFilteredData(data);

    // Préparation des données pour le DashboardRenderer
    const rawDataForDashboard = useMemo(() => {
        if (!data) return {};
        return {
            ...aggregatedData, // totalBudget, plans, breakdowns
            filterOptions,
            filters,
            setFilters, // Passage de la fonction de mise à jour de l'état au Dashboard Live !
            plans: data.plans, // On passe la liste complète des plans pour le KPI "totalPlans"
        };
    }, [aggregatedData, data, filters, filterOptions]);

    const renderSidebar = (
        <div className="flex flex-col h-full bg-[#020617] border-r border-slate-800 w-full p-4">
            <Link href="/" className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-sm transition-colors flex items-center gap-2">
                 <Home size={16} /> Retour à l'Accueil
            </Link>
            <div className="h-px bg-slate-800 my-4 mx-2"></div>
            
            <div className="p-3 bg-violet-500/10 rounded-xl border border-violet-500/30">
               <h3 className="text-xs font-bold uppercase tracking-wider text-violet-400 mb-3 flex items-center gap-2"><Filter size={14} /> Filtres Rapides</h3>
               <div className="space-y-3">
                   {/* Affichage des filtres (lecture seule, car l'interaction est dans le DashboardRenderer) */}
                   <div className="text-xs text-slate-400 flex items-center gap-2">
                      <Briefcase size={12} className="text-slate-500"/>
                      Annonceur: <span className="font-medium text-white">{filterOptions.annonceurs.find(a => a.id === filters.annonceurId)?.name || 'Tous'}</span>
                   </div>
                   <div className="text-xs text-slate-400 flex items-center gap-2">
                      <Target size={12} className="text-slate-500"/>
                      Modèle: <span className="font-medium text-white">{filterOptions.modeles.find(m => m.id === filters.modeleAchatId)?.name || 'Tous'}</span>
                   </div>
                   <button 
                       onClick={() => setFilters({ annonceurId: 'all', modeleAchatId: 'all' })}
                       className="mt-3 w-full py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-[10px] font-bold uppercase text-white transition-colors"
                       disabled={filters.annonceurId === 'all' && filters.modeleAchatId === 'all'}
                   >
                       Réinitialiser
                   </button>
               </div>
            </div>

            <div className="mt-4 p-3 border border-slate-800 rounded-xl">
                 <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Légende Canaux</h3>
                 <ul className="space-y-1">
                     {/* CORRIGÉ: Utilise filterOptions.canaux qui est maintenant défini */}
                     {filterOptions.canaux?.map((c, i) => ( 
                         <li key={i} className="text-[10px] text-slate-400 flex items-center gap-2">
                             <div className="w-2 h-2 rounded-full" style={{backgroundColor: ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06B6D4', '#EC4899'][i % 7]}}></div>
                             {c.name}
                         </li>
                     ))}
                 </ul>
            </div>
        </div>
    );

    const renderContent = () => {
        if (loading) return (
             <div className="flex flex-col items-center justify-center h-full text-violet-400 gap-4">
                <Loader2 size={48} className="animate-spin" />
                <p className="text-sm">Chargement et agrégation des {MEDIA_PLANS_COLLECTION} et {INSERTIONS_COLLECTION}...</p>
            </div>
        );

        if (error) return (
            <div className="flex flex-col items-center justify-center h-full text-red-400 gap-4 p-8">
                <Database size={48} />
                <p className="text-lg font-bold">Erreur de Données</p>
                <p className="text-sm text-center max-w-lg">{error}</p>
            </div>
        );

        return (
            <DashboardRenderer 
                code={PORTFOLIO_DASHBOARD_CODE} 
                rawPlanData={rawDataForDashboard} 
            />
        );
    }

    return (
        <StudioLayout
            leftContent={renderSidebar}
            rightContent={
                <div className="flex flex-col h-full bg-[#0F172A]">
                    {/* HEADER DU MODULE PORTEFEUILLE */}
                    <div className="h-16 border-b border-slate-800 bg-[#0F172A] flex items-center justify-between px-6 flex-shrink-0 z-40">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-violet-900/20 text-white font-bold text-sm">PM</div>
                            <div><div className="text-white font-bold leading-none tracking-tight">Portefeuille Média</div><div className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Vue Direction</div></div>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="text-xs text-slate-600 italic px-4">Données agrégées en temps réel</div>
                        </div>
                    </div>

                    <div className="flex-1 overflow-hidden relative">
                        {renderContent()}
                    </div>
                </div>
            }
            bottomContent={
                <div className="h-9 bg-[#020617] border-t border-slate-800 flex items-center justify-between px-6 text-[10px] text-slate-500 flex-shrink-0 z-50 select-none">
                    <div className="flex items-center gap-4">
                        <span className="font-bold text-slate-400 tracking-wider">MODULE PORTEFEUILLE v1.0</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-violet-500 animate-pulse"></div>
                        <span>ANALYSE STRATÉGIQUE EN COURS</span>
                    </div>
                </div>
            }
        />
    );
}