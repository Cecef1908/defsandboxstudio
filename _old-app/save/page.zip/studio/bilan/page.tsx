'use client';

import React, { useState, useEffect } from 'react';
// Ajout de Link pour la navigation
import Link from 'next/link';
import { 
  Zap, Search, Share2, Check, Copy, ExternalLink, X, Calendar, Globe, Clock, BarChart3, FileText
} from 'lucide-react';

// UI Components
import StudioLayout from "../../components/StudioLayout";
import DashboardRenderer from "../../components/DashboardRenderer"; 

// --- TYPES ---
interface PublishedReport {
    id: string;
    title: string;
    url: string;
    date: string;
    type: string;
}

// --- SYSTEM CLOCK ---
function SystemClock() {
    const [time, setTime] = useState<Date | null>(null);
    useEffect(() => {
        setTime(new Date());
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    if (!time) return <div className="w-16 h-4 bg-slate-800/50 rounded animate-pulse"></div>;

    return (
        <div className="font-mono text-[10px] text-yellow-500 flex items-center gap-2 bg-[#0F172A] px-2 py-1 rounded border border-slate-800 shadow-sm">
            <Clock size={10} />
            {time.toLocaleTimeString('fr-FR')}
        </div>
    );
}

// --- TEMPLATE BILAN (AUTO-CONTENU) ---
const DEFAULT_CODE = `
// --- CONFIGURATION ---
const colors = {
  bg: '#0F172A',
  card: '#1E293B',
  text: '#F8FAFC',
  muted: '#94A3B8',
  primary: '#EAB308', // Yellow for Bilan
  success: '#10B981',
  grid: '#334155'
};

const dataPerformance = [
  { month: 'Jan', ca: 4000, obj: 2400 },
  { month: 'Fev', ca: 3000, obj: 1398 },
  { month: 'Mar', ca: 2000, obj: 9800 },
  { month: 'Avr', ca: 2780, obj: 3908 },
  { month: 'Mai', ca: 1890, obj: 4800 },
  { month: 'Juin', ca: 2390, obj: 3800 },
  { month: 'Juil', ca: 3490, obj: 4300 },
];

const kpis = [
  { label: "Chiffre d'Affaires", val: "1.2M MAD", sub: "+12% vs N-1", color: "text-white" },
  { label: "Marge Brute", val: "320k MAD", sub: "26% du CA", color: "text-yellow-400" },
  { label: "Clients Actifs", val: "142", sub: "+5 ce mois", color: "text-emerald-400" },
  { label: "NPS", val: "72", sub: "Excellent", color: "text-blue-400" },
];

render(
  <div className="min-h-full bg-[#0F172A] font-sans text-slate-100 pb-12">
    
    {/* HEADER RAPPORT */}
    <div className="bg-[#1E293B]/30 border-b border-slate-800 px-8 py-10">
      <div className="flex justify-between items-start max-w-7xl mx-auto">
        <div>
          <div className="flex items-center gap-4 mb-3">
             <div className="p-2 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                <Lucide.BarChart3 size={24} className="text-yellow-500" />
             </div>
             <h1 className="text-4xl font-bold text-white tracking-tight">Bilan Annuel 2025</h1>
          </div>
          <p className="text-slate-400 text-sm max-w-2xl">
            Analyse consolidée des performances de l'agence. Ce rapport inclut les données financières, opérationnelles et la satisfaction client.
          </p>
        </div>
        <div className="text-right hidden md:block">
           <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-2">Dernière mise à jour</div>
           <div className="font-mono text-sm font-medium text-slate-300 bg-slate-900/80 px-4 py-2 rounded-lg border border-slate-800 flex items-center gap-3">
             <Lucide.Calendar size={14} className="text-yellow-500" />
             {new Date().toLocaleDateString('fr-FR')}
           </div>
        </div>
      </div>
    </div>

    <div className="px-8 py-8 max-w-7xl mx-auto space-y-8">
      
      {/* KPIS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
         {kpis.map((kpi, i) => (
           <div key={i} className="bg-[#1E293B] p-6 rounded-2xl border border-slate-800 shadow-xl relative overflow-hidden group hover:border-yellow-500/30 transition-all">
              <div className="relative z-10">
                 <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{kpi.label}</span>
                 <div className={\`text-3xl font-bold mt-2 mb-1 \${kpi.color}\`}>{kpi.val}</div>
                 <span className="text-[10px] text-slate-600 font-medium bg-slate-800 px-1.5 py-0.5 rounded">{kpi.sub}</span>
              </div>
           </div>
         ))}
      </div>

      {/* CHART SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[400px]">
         <div className="lg:col-span-2 bg-[#1E293B] rounded-2xl border border-slate-800 p-6 flex flex-col shadow-lg">
            <h3 className="font-bold text-slate-200 mb-6 flex items-center gap-3 text-xs uppercase tracking-widest">
               <IconActivity size={16} className="text-yellow-500"/>
               Performance Mensuelle
            </h3>
            <div className="flex-1 w-full min-h-0">
               <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={dataPerformance}>
                   <defs>
                     <linearGradient id="colorCa" x1="0" y1="0" x2="0" y2="1">
                       <stop offset="5%" stopColor="#EAB308" stopOpacity={0.3}/>
                       <stop offset="95%" stopColor="#EAB308" stopOpacity={0}/>
                     </linearGradient>
                   </defs>
                   <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                   <XAxis dataKey="month" stroke="#94A3B8" fontSize={12} tickLine={false} axisLine={false} />
                   <YAxis stroke="#94A3B8" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => \`\${value}k\`} />
                   <Tooltip 
                      contentStyle={{borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#0F172A', color: '#fff'}}
                   />
                   <Area type="monotone" dataKey="ca" stroke="#EAB308" strokeWidth={3} fillOpacity={1} fill="url(#colorCa)" />
                   <Area type="monotone" dataKey="obj" stroke="#64748B" strokeWidth={2} strokeDasharray="5 5" fill="transparent" />
                 </AreaChart>
               </ResponsiveContainer>
            </div>
         </div>

         {/* INFO CARD */}
         <div className="bg-gradient-to-br from-yellow-500/10 to-transparent rounded-2xl border border-yellow-500/20 p-8 flex flex-col justify-center items-center text-center">
            <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-yellow-500/20">
               <Lucide.Trophy size={32} className="text-black" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Objectifs Atteints</h3>
            <p className="text-slate-400 text-sm mb-6 leading-relaxed">
               L'équipe a dépassé les objectifs trimestriels de 15%. La stratégie d'acquisition digitale porte ses fruits.
            </p>
            <button className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold py-2 px-6 rounded-lg text-sm transition-colors w-full">
               Voir le détail
            </button>
         </div>
      </div>
    </div>
  </div>
);
`;

export default function BilanStudio() {
    const [currentCode, setCurrentCode] = useState(DEFAULT_CODE);
    const [historyList, setHistoryList] = useState<PublishedReport[]>([]);
    
    // UI States
    const [activeTab, setActiveTab] = useState<'templates' | 'published'>('templates');
    const [publishModalOpen, setPublishModalOpen] = useState(false);
    const [lastPublishedUrl, setLastPublishedUrl] = useState<string | null>(null);
    const [isPublishing, setIsPublishing] = useState(false);

    // Initialisation Historique
    useEffect(() => {
        const saved = localStorage.getItem('bilanHistory');
        if (saved) {
            try { setHistoryList(JSON.parse(saved)); } catch (e) { console.error(e); }
        } else {
            // Historique Factice pour la démo si vide
            setHistoryList([
                { id: 'bilan-q1', title: 'Bilan Q1 2025', url: '#', date: '15/04/2025', type: 'Trimestriel' },
                { id: 'perf-mars', title: 'Performance Mars', url: '#', date: '02/04/2025', type: 'Mensuel' }
            ]);
        }
    }, []);

    // --- PUBLICATION ---
    const handlePublish = async () => {
        setIsPublishing(true);
        try {
            const response = await fetch('/api/publish', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    title: "Bilan Annuel 2025", // Titre extrait ou par défaut
                    code: currentCode, 
                    data: {} // Pas de data externe pour ce template autonome
                })
            });

            const result = await response.json();

            if (result.success) {
                const url = `${window.location.origin}/dashboards/${result.slug}`;
                setLastPublishedUrl(url);
                
                const newReport: PublishedReport = {
                    id: result.slug,
                    title: "Bilan Annuel 2025",
                    url: url,
                    date: new Date().toLocaleDateString(),
                    type: 'Annuel'
                };
                
                const updatedHistory = [newReport, ...historyList];
                setHistoryList(updatedHistory);
                localStorage.setItem('bilanHistory', JSON.stringify(updatedHistory));
                setPublishModalOpen(true);
                setActiveTab('published'); // Basculer vers l'onglet publié pour voir le résultat
            } else {
                alert("Erreur : " + result.message);
            }
        } catch (e) { console.error(e); alert("Erreur réseau."); } 
        finally { setIsPublishing(false); }
    };

    // --- SIDEBAR ---
    const renderSidebar = (
        <div className="flex flex-col h-full bg-[#020617] border-r border-slate-800 w-80 text-slate-300">
            <div className="p-5 border-b border-slate-800 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Rapports</span>
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-bold border border-slate-700">
                        {activeTab === 'templates' ? 1 : historyList.length}
                    </span>
                </div>
                
                <div className="flex bg-[#0F172A] p-1 rounded-lg border border-slate-800">
                    <button onClick={() => setActiveTab('templates')} className={`flex-1 text-xs py-1.5 font-medium rounded transition-all ${activeTab === 'templates' ? 'bg-[#1E293B] text-white shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}>Modèles</button>
                    <button onClick={() => setActiveTab('published')} className={`flex-1 text-xs py-1.5 font-medium rounded transition-all ${activeTab === 'published' ? 'bg-[#1E293B] text-yellow-500 shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}>Historique</button>
                </div>
            </div>
            
            <div className="flex-1 overflow-auto p-3 space-y-1 custom-scrollbar">
                {/* MODELES */}
                {activeTab === 'templates' && (
                    <button className="w-full text-left p-3.5 rounded-xl border bg-[#1E293B] border-yellow-500/50 shadow-lg shadow-yellow-900/10 group">
                        <div className="flex justify-between items-start mb-1">
                            <div className="font-bold text-sm text-white">Bilan Annuel</div>
                            <span className="text-[10px] bg-yellow-500/20 text-yellow-500 px-1.5 py-0.5 rounded font-bold">NEW</span>
                        </div>
                        <div className="text-[10px] text-slate-400">Modèle complet avec KPIs et graphiques financiers.</div>
                    </button>
                )}

                {/* HISTORIQUE */}
                {activeTab === 'published' && historyList.map(report => (
                    <div key={report.id} className="w-full text-left p-3.5 rounded-xl border border-slate-800 bg-[#0F172A] hover:bg-[#1E293B] group relative overflow-hidden transition-colors">
                        <div className="flex justify-between items-start mb-1">
                            <div className="font-bold text-sm text-slate-300 line-clamp-1">{report.title}</div>
                            <a href={report.url} target="_blank" className="text-yellow-500 hover:text-white p-1 bg-slate-800 rounded border border-slate-700 hover:border-yellow-500 transition-colors"><ExternalLink size={12}/></a>
                        </div>
                        <div className="flex justify-between items-center text-[10px] text-slate-500 mt-2">
                            <span className="bg-slate-800/50 px-1.5 py-0.5 rounded text-slate-400">{report.type}</span>
                            <span className="font-mono text-slate-600">{report.date}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    return (
        <StudioLayout
            leftContent={renderSidebar}
            rightContent={
                <div className="flex flex-col h-full bg-[#020617]">
                    {/* HEADER */}
                    <div className="h-16 border-b border-slate-800 bg-[#0F172A] flex items-center justify-between px-6 flex-shrink-0 z-40">
                        <div className="flex items-center gap-6">
                            {/* BOUTON HOME POUR LE BILAN */}
                            <Link href="/" className="flex items-center justify-center p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors border border-slate-700/50">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                            </Link>
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-lg flex items-center justify-center shadow-lg shadow-yellow-900/20 text-white font-bold text-sm">BA</div>
                                <div><div className="text-white font-bold leading-none tracking-tight">Bilan Studio</div><div className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Reporting Center</div></div>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <button onClick={handlePublish} disabled={isPublishing} className={`h-9 px-5 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center gap-2 ${isPublishing ? 'bg-slate-800 text-slate-500 cursor-wait' : 'bg-yellow-500 hover:bg-yellow-400 text-black shadow-lg shadow-yellow-500/20 hover:shadow-yellow-500/40 transform hover:-translate-y-0.5'}`}>
                                {isPublishing ? <div className="animate-spin"><Clock size={12}/></div> : <Share2 size={12} />} {isPublishing ? 'Publication...' : 'Publier le Bilan'}
                            </button>
                        </div>
                    </div>

                    <div className="flex-1 overflow-hidden relative">
                        {/* Pas de rawPlanData nécessaire pour ce template autonome */}
                        <DashboardRenderer code={currentCode} rawPlanData={{}} />
                    </div>

                    {/* MODAL SUCCESS */}
                    {publishModalOpen && (
                        <div className="absolute inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
                            <div className="bg-[#1E293B] border border-slate-700 rounded-2xl shadow-2xl w-full max-w-md p-6 relative">
                                <div className="flex justify-between items-start mb-6">
                                    <div className="flex items-center gap-4">
                                        <div className="w-12 h-12 rounded-full bg-yellow-500/20 text-yellow-400 flex items-center justify-center border border-yellow-500/30"><Check size={24} strokeWidth={3} /></div>
                                        <div><h3 className="text-xl font-bold text-white">Bilan Publié !</h3><p className="text-sm text-slate-400">Le rapport est sécurisé et accessible.</p></div>
                                    </div>
                                    <button onClick={() => setPublishModalOpen(false)} className="text-slate-500 hover:text-white transition-colors"><X size={20} /></button>
                                </div>
                                <div className="bg-[#0F172A] border border-slate-800 rounded-xl p-4 flex items-center gap-3 mb-8 group">
                                    <Globe size={16} className="text-slate-500 group-hover:text-yellow-400 transition-colors" />
                                    <div className="flex-1 font-mono text-xs text-slate-400 truncate select-all">{lastPublishedUrl}</div>
                                    <button onClick={() => navigator.clipboard.writeText(lastPublishedUrl || '')} className="text-yellow-400 hover:text-white p-2 hover:bg-slate-800 rounded-lg transition-colors" title="Copier"><Copy size={16} /></button>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <button onClick={() => setPublishModalOpen(false)} className="py-3 text-sm font-bold text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl border border-slate-700 transition-all">Fermer</button>
                                    <a href={lastPublishedUrl || '#'} target="_blank" className="py-3 bg-yellow-500 hover:bg-yellow-400 text-black text-sm font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-yellow-900/50">Voir le Rapport <ExternalLink size={16} /></a>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            }
            bottomContent={
                <div className="h-9 bg-[#020617] border-t border-slate-800 flex items-center justify-between px-6 text-[10px] text-slate-500 flex-shrink-0 z-50 select-none">
                    <div className="flex items-center gap-4">
                        <span className="font-bold text-slate-400 tracking-wider">BILAN STUDIO v1.0</span>
                        <span className="w-px h-3 bg-slate-800"></span>
                        <span className="flex items-center gap-2"><div className="w-1 h-1 rounded-full bg-yellow-500 animate-pulse"></div> SYSTÈME OPÉRATIONNEL</span>
                    </div>
                    <SystemClock />
                </div>
            } 
        >
            <textarea className="hidden" value={currentCode} onChange={e => setCurrentCode(e.target.value)} />
        </StudioLayout>
    );
}