'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Sparkles, PenTool, Database, Calendar, DollarSign, 
  User, Briefcase, Loader2, ChevronLeft,
  Wand2, Save, X, Plus, ChevronDown, Layers, Target, Home,
  CreditCard, Layout, Trash2, PieChart, Calculator, AlertTriangle, Check, BrainCircuit,
  Eye, MousePointerClick, PlayCircle, Users, AlertOctagon, Settings, UploadCloud, Server,
  ArrowRight, RefreshCw, FileCode, Monitor
} from 'lucide-react';

import StudioLayout from "../../components/StudioLayout"; 

import { 
    db, 
    ANNONCEURS_COLLECTION, 
    MARQUES_COLLECTION, 
    MEDIA_PLANS_COLLECTION, 
    INSERTIONS_COLLECTION,
    authenticateUser 
} from '../../lib/firebase';
import { collection, getDocs, addDoc, setDoc, doc, serverTimestamp } from 'firebase/firestore';

// --- LISTES DÉROULANTES STANDARDISÉES (Basées sur vos JSONs) ---
const CHANNEL_TYPES = [
    "Social", "Search/Display", "Social B2B", "Social Video", 
    "Video", "Outdoor", "Display", "Broadcast", "Direct"
];

const PLACEMENT_TYPES = [
    "feed", "story", "reels", "search", "display", "instream", 
    "homepage", "mix", "bumper", "article"
];

const RATIO_TYPES = [
    "1:1 (Carré)", "9:16 (Vertical)", "16:9 (Horizontal)", 
    "4:5 (Portrait)", "1.91:1 (Paysage)", "Custom", "Multiple"
];

const FILE_TYPES = [
    "JPG / PNG", "MP4 / MOV", "HTML5", "PDF", "Mixte"
];

// --- SEED DATA (Pour initialisation Base Vide) ---
const SEED_CANAUX = [
    { id: 'meta', name: 'Meta Ads', type: 'Social', description: 'Facebook & Instagram' },
    { id: 'google', name: 'Google Ads', type: 'Search/Display', description: 'Search, Display, YouTube' },
    { id: 'linkedin', name: 'LinkedIn Ads', type: 'Social B2B', description: 'Ciblage pro' },
    { id: 'tiktok', name: 'TikTok Ads', type: 'Social Video', description: 'Gen Z & Video' }
];

const FIXED_OBJECTIVES = ["Notoriété", "Considération", "Trafic", "Leads", "Ventes"];

// --- TYPES ---
type CreationMode = 'selection' | 'manual' | 'ai' | 'config';

interface Annonceur { id: string; nomAnnonceur: string; }
interface Marque { id: string; nomMarque: string; annonceurRef: string; }
interface Canal { id: string; name: string; type: string; description?: string; }
interface Format { 
    id: string; name: string; channelId: string; 
    placement?: string; specsDimensions?: string; specsRatio?: string; 
    specsFileType?: string; specsMaxWeight?: string; specsDurationLimit?: string; 
    specsTechnicalNotes?: string;
}
interface BuyingModel { id: string; name: string; unit: string; }

interface DraftInsertion {
    id: string;
    canal: string;
    canalId: string; 
    format: string;
    formatId: string; 
    modeleAchat: string;
    coutUnitaire: number;
    quantiteAchetee: number;
    budget: number;
    targeting: string; 
}

// --- UTILITAIRES ---
const generateSlug = (text: string) => text.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
const generatePlanID = () => `PM-${new Date().getFullYear()}-Q${Math.floor((new Date().getMonth() + 3) / 3)}-${Math.floor(1000 + Math.random() * 9000)}`;
const generateInsertionID = () => `INS-${Date.now().toString().slice(-8)}`;

export default function NewPlanPage() {
    
    // UI
    const [mode, setMode] = useState<CreationMode>('selection');
    const [isLoadingData, setIsLoadingData] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [dataStatus, setDataStatus] = useState<'loading' | 'success' | 'empty'>('loading');
    const [isConfigSaving, setIsConfigSaving] = useState(false); // Ajout pour le chargement Admin
    
    // DATA
    const [annonceurs, setAnnonceurs] = useState<Annonceur[]>([]);
    const [marques, setMarques] = useState<Marque[]>([]);
    const [canaux, setCanaux] = useState<Canal[]>([]);
    const [formats, setFormats] = useState<Format[]>([]);
    const [buyingModels, setBuyingModels] = useState<BuyingModel[]>([]);

    // FORM DATA
    const [formData, setFormData] = useState({
        nomPlan: '',
        annonceurId: '',
        marqueIds: [] as string[], 
        budget: '', 
        dateDebut: '',
        dateFin: '',
        objectifs: [] as string[],
        description: '' 
    });

    // ADMIN CONFIG
    const [configTab, setConfigTab] = useState<'canaux' | 'formats'>('canaux');
    
    // State Admin Canal
    const [newCanal, setNewCanal] = useState({ name: '', type: 'Social', description: '' });
    
    // State Admin Format (Complet)
    const [newFormat, setNewFormat] = useState<Partial<Format>>({ 
        name: '', channelId: '', placement: 'feed', 
        specsDimensions: '', specsMaxWeight: '', specsRatio: '1:1 (Carré)', 
        specsFileType: 'JPG / PNG', specsDurationLimit: '', specsTechnicalNotes: '' 
    });

    // QUICK INSERT
    const [draftInsertions, setDraftInsertions] = useState<DraftInsertion[]>([]);
    const [newIns, setNewIns] = useState({ 
        canalId: '', formatId: '', modele: 'CPM', 
        coutUnitaire: '', budget: '', targeting: '' 
    });

    // AI
    const [aiPrompt, setAiPrompt] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [isSimulatingAI, setIsSimulatingAI] = useState(false); 

    // --- LOAD DATA ---
    const loadDatabase = async () => {
        setIsLoadingData(true);
        try {
            await authenticateUser();

            const [annSnap, marqSnap, cSnap, fSnap, mSnap] = await Promise.all([
                getDocs(collection(db, ANNONCEURS_COLLECTION)),
                getDocs(collection(db, MARQUES_COLLECTION)),
                getDocs(collection(db, 'canaux')),
                getDocs(collection(db, 'formats')),
                getDocs(collection(db, 'buyingModels'))
            ]);

            setAnnonceurs(annSnap.docs.map(d => ({ id: d.id, ...d.data() } as Annonceur)).sort((a,b) => a.nomAnnonceur.localeCompare(b.nomAnnonceur)));
            setMarques(marqSnap.docs.map(d => ({ id: d.id, ...d.data() } as Marque)));
            
            const loadedCanaux = cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Canal));
            const loadedFormats = fSnap.docs.map(d => ({ id: d.id, ...d.data() } as Format));
            const loadedModels = mSnap.docs.map(d => ({ id: d.id, ...d.data() } as BuyingModel));

            setCanaux(loadedCanaux);
            setFormats(loadedFormats);
            setBuyingModels(loadedModels);

            if (loadedCanaux.length === 0) setDataStatus('empty');
            else setDataStatus('success');

            if (loadedCanaux.length > 0 && !newIns.canalId) {
                setNewIns(prev => ({ ...prev, canalId: loadedCanaux[0].id }));
            }

        } catch (error) {
            console.error("Erreur chargement:", error);
        } finally {
            setIsLoadingData(false);
        }
    };

    useEffect(() => {
        if (mode !== 'selection') loadDatabase();
    }, [mode]);

    // --- FILTRES ---
    const filteredMarques = useMemo(() => 
        formData.annonceurId ? marques.filter(m => m.annonceurRef === formData.annonceurId) : []
    , [formData.annonceurId, marques]);

    const filteredFormats = useMemo(() => {
        if (!newIns.canalId) return formats;
        return formats.filter(f => f.channelId === newIns.canalId);
    }, [newIns.canalId, formats]);

    // --- CALCUL VOLUME ---
    const calculatedVolume = useMemo(() => {
        const b = parseFloat(newIns.budget);
        const cu = parseFloat(newIns.coutUnitaire);
        if (!b || !cu || cu === 0) return 0;
        const modelLower = newIns.modele.toLowerCase();
        if (modelLower.includes('cpm')) return Math.floor((b / cu) * 1000);
        return Math.floor(b / cu);
    }, [newIns.budget, newIns.coutUnitaire, newIns.modele]);

    // --- GESTION FORMULAIRE UTILS (Définis une seule fois ici) ---
    const toggleMarque = (id: string) => {
        setFormData(prev => {
            const exists = prev.marqueIds.includes(id);
            if (exists) return { ...prev, marqueIds: prev.marqueIds.filter(m => m !== id) };
            return { ...prev, marqueIds: [...prev.marqueIds, id] };
        });
    };

    const toggleObjective = (obj: string) => {
        setFormData(prev => {
            const exists = prev.objectifs.includes(obj);
            if (exists) return { ...prev, objectifs: prev.objectifs.filter(o => o !== obj) };
            return { ...prev, objectifs: [...prev.objectifs, obj] };
        });
    };

    // --- ADMIN ACTIONS (ADD & INIT) ---
    
    const initializeDatabase = async () => {
        if (!confirm("Injecter les données SEED ?")) return;
        setIsLoadingData(true);
        try {
            await authenticateUser();
            for (const c of SEED_CANAUX) await setDoc(doc(db, 'canaux', c.id), c);
            
            alert("Base initialisée. Rafraîchissement...");
            loadDatabase(); 
        } catch (e: any) { console.error(e); alert(`Erreur: ${e.message}`); } finally { setIsLoadingData(false); }
    };

    const handleAddCanal = async () => {
        if (!newCanal.name) return alert("Nom requis");
        setIsConfigSaving(true);
        const slugId = generateSlug(newCanal.name);
        try {
            await setDoc(doc(db, 'canaux', slugId), { 
                ...newCanal, 
                id: slugId,
                createdAt: serverTimestamp()
            });
            
            setNewCanal({ name: '', type: 'Social', description: '' });
            
            // HACK DE SYNCHRO: Attendre 100ms avant de recharger pour laisser le temps à Firestore de se propager
            await new Promise(resolve => setTimeout(resolve, 100)); 
            await loadDatabase(); 
            alert("Canal ajouté avec succès !");
        } catch (e: any) { 
            console.error("Erreur Firestore lors de l'ajout du canal:", e);
            alert(`Erreur d'écriture Firebase: ${e.message}`); 
        } finally {
            setIsConfigSaving(false);
        }
    };

    const handleAddFormat = async () => {
        if (!newFormat.name || !newFormat.channelId) return alert("Nom et Canal requis");
        setIsConfigSaving(true);
        try {
            await addDoc(collection(db, 'formats'), {
                ...newFormat,
                createdAt: serverTimestamp()
            });
            
            setNewFormat({ 
                name: '', channelId: '', placement: 'feed', 
                specsDimensions: '', specsMaxWeight: '', specsRatio: '1:1 (Carré)', 
                specsFileType: 'JPG / PNG', specsDurationLimit: '', specsTechnicalNotes: '' 
            });
            
            // HACK DE SYNCHRO
            await new Promise(resolve => setTimeout(resolve, 100)); 
            await loadDatabase();
            alert("Format ajouté avec succès !");
        } catch (e: any) { 
            console.error("Erreur Firestore lors de l'ajout du format:", e);
            alert(`Erreur d'écriture Firebase: ${e.message}`); 
        } finally {
            setIsConfigSaving(false);
        }
    };

    // --- GESTION PLAN & INSERTIONS ---
    const handleAddInsertion = () => {
        if (!newIns.canalId || !newIns.budget) return;
        const canalObj = canaux.find(c => c.id === newIns.canalId);
        const formatObj = formats.find(f => f.id === newIns.formatId);
        const b = parseFloat(newIns.budget);
        const cu = parseFloat(newIns.coutUnitaire) || 0;
        
        if (b <= 0) return;

        const item: DraftInsertion = {
            id: Date.now().toString(),
            canal: canalObj?.name || 'Inconnu',
            canalId: newIns.canalId,
            format: formatObj?.name || 'Standard',
            formatId: newIns.formatId || 'standard',
            modeleAchat: newIns.modele,
            coutUnitaire: cu,
            quantiteAchetee: calculatedVolume,
            budget: b,
            targeting: newIns.targeting || 'Non spécifié'
        };

        setDraftInsertions([...draftInsertions, item]);
        setNewIns(prev => ({ ...prev, budget: '', coutUnitaire: '', targeting: '' })); 
    };

    const handleCreatePlan = async () => {
        if (!formData.nomPlan.trim()) return alert("Nom requis.");
        if (!formData.annonceurId) return alert("Annonceur requis.");
        
        setIsSubmitting(true);
        try {
            await authenticateUser();
            const customPlanId = generatePlanID();
            const finalBudget = formData.budget ? parseFloat(formData.budget) : draftInsertions.reduce((acc, curr) => acc + curr.budget, 0);

            await setDoc(doc(db, MEDIA_PLANS_COLLECTION, customPlanId), {
                idPlan: customPlanId,
                nomPlan: formData.nomPlan.trim(),
                status: 'Brouillon',
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
                annonceurRef: formData.annonceurId, 
                marquesRefs: formData.marqueIds, 
                budgetTotal: finalBudget,
                commissionRate: 15,
                feesRate: 5,
                dateDebut: formData.dateDebut ? new Date(formData.dateDebut) : null,
                dateFin: formData.dateFin ? new Date(formData.dateFin) : null,     
                objectifs: formData.objectifs, 
                objectifPrincipal: formData.objectifs[0] || "Non défini",
                description: formData.description
            });

            const promises = draftInsertions.map(ins => {
                const insId = generateInsertionID();
                return setDoc(doc(db, INSERTIONS_COLLECTION, insId), {
                    idInsertion: insId,
                    planRef: customPlanId,
                    canal: ins.canal,
                    format: ins.format,
                    channelId: ins.canalId,
                    formatId: ins.formatId,
                    modeleAchat: ins.modeleAchat,
                    coutUnitaire: ins.coutUnitaire,
                    quantiteAchetee: ins.quantiteAchetee,
                    coutEstime: ins.budget,
                    nomInsertion: `${ins.canal} - ${ins.format}`,
                    status: 'Brouillon',
                    createdAt: serverTimestamp(),
                    targeting: ins.targeting 
                });
            });
            
            await Promise.all(promises);
            window.location.href = `/studio/plan-media?planId=${customPlanId}`;

        } catch (e: any) {
            console.error("Erreur création plan:", e);
            alert(`Erreur de création du plan : ${e.message}`);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleSimulateAI = () => {
        setIsSimulatingAI(true);
        setTimeout(() => { setIsSimulatingAI(false); alert("Module IA bientôt disponible."); }, 1000);
    };

    // --- CALCULS ---
    const totalAllocated = draftInsertions.reduce((acc, curr) => acc + curr.budget, 0);
    const manualBudget = parseFloat(formData.budget);
    const isBudgetManual = !isNaN(manualBudget) && manualBudget > 0;
    const finalBudget = isBudgetManual ? manualBudget : totalAllocated;
    const isOverBudget = isBudgetManual && totalAllocated > finalBudget;
    const remainingBudget = isBudgetManual ? finalBudget - totalAllocated : 0;
    
    const metrics = useMemo(() => {
        let imps = 0, clicks = 0, views = 0, leads = 0;
        draftInsertions.forEach(ins => {
            const qty = ins.quantiteAchetee || 0;
            const model = ins.modeleAchat.toLowerCase();
            if (model.includes('cpm') || ins.format.toLowerCase().includes('display')) imps += qty;
            if (model.includes('cpc')) clicks += qty;
            if (model.includes('cpv') || ins.format.toLowerCase().includes('video')) views += qty;
            if (model.includes('cpl')) leads += qty;
        });
        return { imps, clicks, views, leads };
    }, [draftInsertions]);

    // --- RENDERERS ---

    const renderConfigScreen = () => (
        <div className="h-full flex flex-col animate-in slide-in-from-right-4 duration-500">
            <div className="px-8 py-5 border-b border-slate-800 flex items-center justify-between bg-[#0F172A]/90 backdrop-blur-md sticky top-0 z-30">
                <div className="flex items-center gap-6">
                    <button onClick={() => setMode('selection')} className="flex items-center text-slate-500 hover:text-white text-xs font-bold uppercase tracking-wider transition-colors hover:bg-slate-800 px-3 py-2 rounded-lg">
                        <ChevronLeft size={14} className="mr-2" /> Retour
                    </button>
                    <div className="h-6 w-px bg-slate-800"></div>
                    <h2 className="text-white font-bold flex items-center gap-2">
                        <Settings size={18} className="text-indigo-500"/> Configuration Système
                    </h2>
                </div>
                <div className="flex items-center gap-3">
                    <button onClick={loadDatabase} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition-colors" title="Rafraîchir les données">
                        <RefreshCw size={16} className={isLoadingData ? 'animate-spin' : ''} />
                    </button>
                    {canaux.length === 0 && (
                        <button onClick={initializeDatabase} className="px-4 py-2 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/50 rounded-lg text-xs font-bold flex items-center gap-2 transition-all">
                            <UploadCloud size={14} /> Initialiser Base
                        </button>
                    )}
                </div>
            </div>

            <div className="flex-1 overflow-auto p-8 custom-scrollbar">
                <div className="max-w-7xl mx-auto space-y-8">
                    {/* TABS */}
                    <div className="flex space-x-4 border-b border-slate-800">
                        <button onClick={() => setConfigTab('canaux')} className={`pb-3 px-2 text-sm font-bold border-b-2 transition-colors ${configTab === 'canaux' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-300'}`}>Canaux Média</button>
                        <button onClick={() => setConfigTab('formats')} className={`pb-3 px-2 text-sm font-bold border-b-2 transition-colors ${configTab === 'formats' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-300'}`}>Formats Publicitaires</button>
                    </div>

                    {/* CANAUX ADMIN */}
                    {configTab === 'canaux' && (
                        <div className="space-y-6 animate-in fade-in">
                            <div className="bg-[#1E293B] rounded-xl p-6 border border-slate-800 shadow-lg">
                                <h4 className="text-xs font-bold text-slate-400 uppercase mb-4 flex items-center gap-2"><Plus size={14}/> Créer un Canal</h4>
                                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                                    <div className="md:col-span-3">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Nom du Canal</label>
                                        <input type="text" className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:border-indigo-500 outline-none" value={newCanal.name} onChange={e=>setNewCanal({...newCanal, name: e.target.value})} placeholder="Ex: Snapchat Ads" />
                                    </div>
                                    <div className="md:col-span-3">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Type</label>
                                        <select className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:border-indigo-500 outline-none" value={newCanal.type} onChange={e=>setNewCanal({...newCanal, type: e.target.value})}>
                                            {CHANNEL_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                                        </select>
                                    </div>
                                    <div className="md:col-span-4">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Description</label>
                                        <input type="text" className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:border-indigo-500 outline-none" value={newCanal.description} onChange={e=>setNewCanal({...newCanal, description: e.target.value})} placeholder="Optionnel" />
                                    </div>
                                    <div className="md:col-span-2">
                                        <button onClick={handleAddCanal} disabled={!newCanal.name || isConfigSaving} className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg p-2.5 text-sm font-bold flex justify-center items-center gap-2 disabled:opacity-50">
                                            {isConfigSaving ? <Loader2 size={16} className="animate-spin"/> : <Save size={16}/>} Ajouter
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                {canaux.map(c => (
                                    <div key={c.id} className="bg-[#1E293B] border border-slate-700 rounded-xl p-4 group hover:border-slate-500 transition-colors">
                                        <div>
                                            <div className="font-bold text-white mb-1 flex items-center justify-between">
                                                {c.name}
                                                <span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 font-normal">{c.id}</span>
                                            </div>
                                            <div className="text-xs text-indigo-400 mb-2">{c.type}</div>
                                            {c.description && <div className="text-[10px] text-slate-500 line-clamp-2">{c.description}</div>}
                                        </div>
                                        <div className="text-slate-700"><Server size={14} /></div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* FORMATS ADMIN */}
                    {configTab === 'formats' && (
                        <div className="space-y-6 animate-in fade-in">
                            <div className="bg-[#1E293B] rounded-xl p-6 border border-slate-800 shadow-lg">
                                <h4 className="text-xs font-bold text-slate-400 uppercase mb-4 flex items-center gap-2"><Plus size={14}/> Créer un Format</h4>
                                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                                    
                                    {/* LIGNE 1 */}
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Canal Parent</label>
                                        <select className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white focus:border-indigo-500 outline-none" value={newFormat.channelId} onChange={e=>setNewFormat({...newFormat, channelId: e.target.value})}>
                                            <option value="">Sélectionner...</option>
                                            {canaux.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                        </select>
                                    </div>
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Nom Format</label>
                                        <input type="text" className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.name} onChange={e=>setNewFormat({...newFormat, name: e.target.value})} placeholder="Ex: Story" />
                                    </div>
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Placement</label>
                                        <select className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.placement} onChange={e=>setNewFormat({...newFormat, placement: e.target.value})}>
                                            {PLACEMENT_TYPES.map(p => <option key={p} value={p}>{p}</option>)}
                                        </select>
                                    </div>
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Dimensions</label>
                                        <input type="text" className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.specsDimensions} onChange={e=>setNewFormat({...newFormat, specsDimensions: e.target.value})} placeholder="Ex: 1080x1920" />
                                    </div>
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Ratio</label>
                                        <select className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.specsRatio} onChange={e=>setNewFormat({...newFormat, specsRatio: e.target.value})}>
                                            {RATIO_TYPES.map(r => <option key={r} value={r}>{r}</option>)}
                                        </select>
                                    </div>

                                    {/* LIGNE 2 */}
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Fichiers</label>
                                        <select className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.specsFileType} onChange={e=>setNewFormat({...newFormat, specsFileType: e.target.value})}>
                                            {FILE_TYPES.map(f => <option key={f} value={f}>{f}</option>)}
                                        </select>
                                    </div>
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Poids Max</label>
                                        <input type="text" className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.specsMaxWeight} onChange={e=>setNewFormat({...newFormat, specsMaxWeight: e.target.value})} placeholder="Ex: 4GB" />
                                    </div>
                                    <div className="md:col-span-1">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Durée Limite</label>
                                        <input type="text" className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.specsDurationLimit} onChange={e=>setNewFormat({...newFormat, specsDurationLimit: e.target.value})} placeholder="Ex: 15s" />
                                    </div>
                                    <div className="md:col-span-2">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold mb-1 block">Notes Techniques</label>
                                        <input type="text" className="w-full bg-[#0F172A] border border-slate-700 rounded-lg p-2 text-xs text-white" value={newFormat.specsTechnicalNotes} onChange={e=>setNewFormat({...newFormat, specsTechnicalNotes: e.target.value})} placeholder="Zones de sécurité..." />
                                    </div>

                                    <div className="md:col-span-5 flex justify-end pt-2">
                                        <button onClick={handleAddFormat} disabled={!newFormat.name || !newFormat.channelId || isConfigSaving} className="bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-6 py-2 text-sm font-bold flex items-center gap-2 disabled:opacity-50">
                                            {isConfigSaving ? <Loader2 size={16} className="animate-spin"/> : <Save size={16}/>} Enregistrer le Format
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div className="space-y-4">
                                {canaux.map(c => {
                                    const linkedFormats = formats.filter(f => f.channelId === c.id);
                                    if(linkedFormats.length === 0) return null;
                                    return (
                                        <div key={c.id} className="border border-slate-800 rounded-xl overflow-hidden">
                                            <div className="bg-slate-900 px-4 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider">{c.name}</div>
                                            <div className="divide-y divide-slate-800">
                                                {linkedFormats.map(f => (
                                                    <div key={f.id} className="p-3 bg-[#1E293B] flex justify-between items-center group">
                                                        <div>
                                                            <span className="text-sm font-bold text-white mr-3">{f.name}</span>
                                                            <span className="text-xs text-slate-500 font-mono">
                                                                {f.specsDimensions || 'N/A'} • {f.specsRatio || 'N/A'}
                                                            </span>
                                                        </div>
                                                        <div className="text-slate-700"><Server size={14} /></div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );

    const renderManualForm = () => (
        <div className="h-full flex flex-col animate-in slide-in-from-bottom-4 duration-500">
            {/* ... (Header et Code Formulaire Média Planner inchangés mais inclus dans le bloc final) ... */}
            <div className="px-8 py-5 border-b border-slate-800 flex items-center justify-between bg-[#0F172A]/90 backdrop-blur-md sticky top-0 z-30 shadow-sm">
                <div className="flex items-center gap-6">
                    <button onClick={() => setMode('selection')} className="flex items-center text-slate-500 hover:text-white text-xs font-bold uppercase tracking-wider transition-colors hover:bg-slate-800 px-3 py-2 rounded-lg">
                        <ChevronLeft size={14} className="mr-2" /> Retour
                    </button>
                    <div className="h-6 w-px bg-slate-800"></div>
                    <h2 className="text-white font-bold flex items-center gap-2">
                        <PenTool size={18} className="text-indigo-500"/> Configuration Campagne
                    </h2>
                </div>
                
                <div className="flex items-center gap-3">
                    <button 
                        onClick={handleSimulateAI}
                        disabled={isSimulatingAI}
                        className="px-4 py-3 rounded-xl text-xs font-bold text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500/10 transition-all flex items-center gap-2"
                    >
                         {isSimulatingAI ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />} 
                         {isSimulatingAI ? 'Analyse...' : 'Pré-remplir avec IA'}
                    </button>

                    <button 
                        onClick={handleCreatePlan}
                        disabled={isSubmitting || !formData.annonceurId}
                        className={`px-8 py-3 rounded-xl text-sm font-bold text-white shadow-xl flex items-center gap-3 transition-all transform active:scale-95 ${
                            isSubmitting || !formData.annonceurId ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-500'
                        }`}
                    >
                        {isSubmitting ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                        {isSubmitting ? 'Enregistrement...' : 'Valider le Plan'}
                    </button>
                </div>
            </div>

            <div className="flex-1 overflow-auto p-8 custom-scrollbar">
                <div className="max-w-7xl mx-auto grid grid-cols-1 xl:grid-cols-3 gap-8">
                    
                    <div className="xl:col-span-2 space-y-6">
                        
                        {dataStatus === 'empty' && (
                            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center gap-3 text-amber-400 text-xs">
                                <AlertTriangle size={16} />
                                <span>Base de données vide. Veuillez initialiser les données via le mode Admin ou le bouton d'accueil.</span>
                            </div>
                        )}

                        {/* 1. IDENTITÉ */}
                        <div className="bg-[#1E293B] border border-slate-800 rounded-2xl p-8 shadow-lg">
                            <h3 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-6 flex items-center gap-2 border-b border-slate-800 pb-4">
                                <User size={16} /> Identité & Client
                            </h3>
                            <div className="space-y-6">
                                {/* Annonceur */}
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-slate-300 ml-1">Annonceur <span className="text-red-500">*</span></label>
                                    <div className="relative">
                                        <Briefcase className="absolute left-4 top-3.5 text-slate-500" size={18} />
                                        <select 
                                            value={formData.annonceurId}
                                            onChange={(e) => setFormData({...formData, annonceurId: e.target.value, marqueIds: []})}
                                            className="w-full bg-[#0F172A] border border-slate-700 rounded-xl py-3.5 pl-12 pr-10 text-sm text-slate-200 focus:border-indigo-500 outline-none appearance-none"
                                        >
                                            <option value="">Sélectionner un compte...</option>
                                            {annonceurs.map(a => <option key={a.id} value={a.id}>{a.nomAnnonceur}</option>)}
                                        </select>
                                        <ChevronDown className="absolute right-4 top-4 text-slate-500 pointer-events-none" size={16} />
                                    </div>
                                </div>

                                {/* Sélecteur Multi-Marques */}
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-slate-300 ml-1">Marques Concernées (Multi-sélection)</label>
                                    <div className="p-4 bg-[#0F172A] border border-slate-700 rounded-xl min-h-[80px]">
                                        {!formData.annonceurId ? (
                                            <div className="text-slate-500 text-xs italic">Sélectionnez un annonceur pour voir les marques.</div>
                                        ) : filteredMarques.length === 0 ? (
                                            <div className="text-slate-500 text-xs italic">Aucune marque trouvée pour cet annonceur.</div>
                                        ) : (
                                            <div className="flex flex-wrap gap-2">
                                                {filteredMarques.map(m => {
                                                    const isSelected = formData.marqueIds.includes(m.id);
                                                    return (
                                                        <button 
                                                            key={m.id}
                                                            onClick={() => toggleMarque(m.id)}
                                                            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all flex items-center gap-2 ${isSelected ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-900/50' : 'bg-slate-800 text-slate-400 border-slate-700 hover:border-slate-500'}`}
                                                        >
                                                            {m.nomMarque}
                                                            {isSelected && <Check size={12} />}
                                                        </button>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* 2. CONFIGURATION GLOBALE */}
                        <div className="bg-[#1E293B] border border-slate-800 rounded-2xl p-8 shadow-lg">
                             <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-widest mb-6 flex items-center gap-2 border-b border-slate-800 pb-4">
                                <Layers size={16} /> Configuration Stratégique
                            </h3>

                            <div className="space-y-8">
                                <div className="space-y-3">
                                    <label className="text-xs font-bold text-slate-300 ml-1">Nom Campagne</label>
                                    <div className="relative">
                                        <Layout className="absolute left-4 top-3.5 text-slate-500" size={18} />
                                        <input 
                                            type="text" 
                                            value={formData.nomPlan}
                                            onChange={(e) => setFormData({...formData, nomPlan: e.target.value})}
                                            placeholder="Ex: Lancement Été 2025" 
                                            className="w-full bg-[#0F172A] border border-slate-700 rounded-xl py-3.5 pl-12 pr-4 text-sm text-white focus:border-indigo-500 outline-none"
                                        />
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                    <div className="space-y-3">
                                        <label className="text-xs font-bold text-slate-300 ml-1">Budget Total (MAD) <span className="text-slate-500 font-normal ml-2 italic text-[10px]">Optionnel - Laisser vide pour calcul auto</span></label>
                                        <div className="relative">
                                            <div className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-emerald-400">
                                                <DollarSign size={18} />
                                            </div>
                                            <input 
                                                type="number" 
                                                value={formData.budget}
                                                onChange={(e) => setFormData({...formData, budget: e.target.value})}
                                                placeholder="Auto-calculé si vide" 
                                                className={`w-full bg-[#0F172A] border rounded-xl py-3.5 pl-12 pr-4 text-lg text-white font-mono font-bold focus:border-emerald-500 outline-none border-slate-700`}
                                            />
                                        </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-2">
                                        <div className="space-y-3">
                                            <label className="text-xs font-bold text-slate-300 ml-1">Début</label>
                                            <input type="date" value={formData.dateDebut} onChange={(e) => setFormData({...formData, dateDebut: e.target.value})} className="w-full bg-[#0F172A] border border-slate-700 rounded-xl py-3.5 px-3 text-xs text-white focus:border-indigo-500 outline-none [color-scheme:dark]" />
                                        </div>
                                        <div className="space-y-3">
                                            <label className="text-xs font-bold text-slate-300 ml-1">Fin</label>
                                            <input type="date" value={formData.dateFin} onChange={(e) => setFormData({...formData, dateFin: e.target.value})} className="w-full bg-[#0F172A] border border-slate-700 rounded-xl py-3.5 px-3 text-xs text-white focus:border-indigo-500 outline-none [color-scheme:dark]" />
                                        </div>
                                    </div>
                                </div>

                                {/* OBJECTIFS & DESCRIPTION */}
                                <div className="grid grid-cols-1 gap-6 pt-4 border-t border-slate-800 border-dashed">
                                    <div className="space-y-3">
                                        <label className="text-xs font-bold text-slate-300 ml-1">Objectifs Principaux</label>
                                        <div className="p-4 bg-[#0F172A] rounded-xl border border-slate-700">
                                            <div className="flex flex-wrap gap-2">
                                                {FIXED_OBJECTIVES.map(obj => {
                                                    const isSelected = formData.objectifs.includes(obj);
                                                    return (
                                                        <button
                                                            key={obj}
                                                            onClick={() => toggleObjective(obj)}
                                                            className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wide border transition-all flex items-center gap-1 ${isSelected ? 'bg-indigo-500 text-white border-indigo-500' : 'bg-[#1E293B] text-slate-400 border-slate-600 hover:border-slate-400'}`}
                                                        >
                                                            {obj} {isSelected && <Check size={10} />}
                                                        </button>
                                                    )
                                                })}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="space-y-3">
                                        <label className="text-xs font-bold text-slate-300 ml-1">Description de la Campagne</label>
                                        <div className="relative">
                                            <BrainCircuit className="absolute left-4 top-3.5 text-slate-500" size={18} />
                                            <textarea 
                                                value={formData.description}
                                                onChange={(e) => setFormData({...formData, description: e.target.value})}
                                                placeholder="Contexte, enjeux, cible, message clé..." 
                                                className="w-full bg-[#0F172A] border border-slate-700 rounded-xl py-3.5 pl-12 pr-4 text-sm text-white focus:border-indigo-500 outline-none min-h-[80px] resize-none"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        /* 3. QUICK INSERT */
                        <div className="bg-[#1E293B] border border-slate-800 rounded-2xl p-8 shadow-lg">
                             <h3 className="text-xs font-bold text-amber-400 uppercase tracking-widest mb-6 flex items-center gap-2 border-b border-slate-800 pb-4">
                                <PieChart size={16} /> Allocations Média Rapides
                            </h3>
                            
                            <div className="bg-[#0F172A] rounded-xl p-4 border border-slate-700 mb-6 shadow-inner">
                                <div className="grid grid-cols-12 gap-3 items-end">
                                    <div className="col-span-2 space-y-1">
                                        <label className="text-[9px] font-bold text-slate-400 uppercase">Canal</label>
                                        <select className="w-full bg-[#1E293B] border border-slate-600 rounded-lg p-2 text-xs text-white focus:border-amber-400 outline-none h-9" value={newIns.canalId} onChange={(e) => setNewIns({...newIns, canalId: e.target.value, formatId: ''})}>
                                            <option value="" disabled>Choisir...</option>
                                            {canaux.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                        </select>
                                    </div>
                                    <div className="col-span-2 space-y-1">
                                        <label className="text-[9px] font-bold text-slate-400 uppercase">Format</label>
                                        <select className="w-full bg-[#1E293B] border border-slate-600 rounded-lg p-2 text-xs text-white focus:border-amber-400 outline-none h-9" value={newIns.formatId} onChange={(e) => setNewIns({...newIns, formatId: e.target.value})} disabled={!newIns.canalId}>
                                            <option value="">Tous</option>
                                            {filteredFormats.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                                        </select>
                                    </div>
                                    <div className="col-span-3 space-y-1">
                                        <label className="text-[9px] font-bold text-slate-400 uppercase">Ciblage Spécifique</label>
                                        <input type="text" placeholder="Ex: Retargeting..." className="w-full bg-[#0F172A] border border-slate-600 rounded-lg p-2 text-xs text-white focus:border-amber-400 outline-none h-9" value={newIns.targeting} onChange={(e) => setNewIns({...newIns, targeting: e.target.value})} />
                                    </div>
                                    <div className="col-span-2 space-y-1">
                                        <label className="text-[9px] font-bold text-slate-400 uppercase">Modèle & C.U.</label>
                                        <div className="flex gap-1">
                                            <select className="w-1/2 bg-[#1E293B] border border-slate-600 rounded-lg p-2 text-[10px] text-white focus:border-amber-400 outline-none h-9" value={newIns.modele} onChange={(e) => setNewIns({...newIns, modele: e.target.value})}>
                                                {buyingModels.map(m => <option key={m.id} value={m.name}>{m.name}</option>)}
                                            </select>
                                            <input type="number" placeholder="CU" className="w-1/2 bg-[#1E293B] border border-slate-600 rounded-lg p-2 text-xs text-white font-mono focus:border-amber-400 outline-none h-9" value={newIns.coutUnitaire} onChange={(e) => setNewIns({...newIns, coutUnitaire: e.target.value})} />
                                        </div>
                                    </div>
                                    <div className="col-span-3 space-y-1 relative">
                                        <label className="text-[9px] font-bold text-slate-400 uppercase">Budget Ligne</label>
                                        <input type="number" className="w-full bg-[#1E293B] border border-slate-600 rounded-lg p-2 text-xs text-white font-mono focus:border-amber-400 outline-none h-9 pr-8" value={newIns.budget} onChange={(e) => setNewIns({...newIns, budget: e.target.value})} onKeyDown={(e) => e.key === 'Enter' && handleAddInsertion()} />
                                        <button onClick={handleAddInsertion} className="absolute right-0 bottom-0 h-9 w-8 bg-amber-500 hover:bg-amber-400 text-[#0F172A] rounded-r-lg font-bold flex items-center justify-center transition-colors"><Plus size={16} /></button>
                                    </div>
                                </div>
                                {calculatedVolume > 0 && <div className="mt-2 text-[10px] text-slate-500 flex items-center gap-2"><Calculator size={10} className="text-amber-500"/> Volume Est. : <span className="font-mono text-amber-400 font-bold">{calculatedVolume.toLocaleString()}</span> unités</div>}
                            </div>

                            /* LISTE */
                            {draftInsertions.length > 0 ? (
                                <div className="border border-slate-700 rounded-xl overflow-hidden bg-[#0F172A]/30">
                                    <table className="w-full text-xs text-left">
                                        <thead className="text-[9px] uppercase bg-slate-800 text-slate-400 font-bold tracking-wider">
                                            <tr>
                                                <th className="px-4 py-3">Support & Ciblage</th>
                                                <th className="px-4 py-3">Achat</th>
                                                <th className="px-4 py-3 text-right">C.U.</th>
                                                <th className="px-4 py-3 text-right">Volume</th>
                                                <th className="px-4 py-3 text-right">Budget</th>
                                                <th className="px-4 py-3 text-center w-10"></th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-slate-700/50">
                                            {draftInsertions.map((item) => (
                                                <tr key={item.id} className="hover:bg-[#1E293B] transition-colors group">
                                                    <td className="px-4 py-2">
                                                        <div className="font-bold text-slate-200">{item.canal} <span className="text-slate-500 font-normal">/ {item.format}</span></div>
                                                        <div className="text-[10px] text-indigo-400 mt-0.5 flex items-center gap-1"><Target size={8} /> {item.targeting}</div>
                                                    </td>
                                                    <td className="px-4 py-2 text-slate-400 font-mono">{item.modeleAchat}</td>
                                                    <td className="px-4 py-2 text-right text-slate-500 font-mono">{item.coutUnitaire}</td>
                                                    <td className="px-4 py-2 text-right text-slate-300 font-mono">{item.quantiteAchetee.toLocaleString()}</td>
                                                    <td className="px-4 py-2 text-right font-bold font-mono text-emerald-400">{item.budget.toLocaleString()}</td>
                                                    <td className="px-4 py-2 text-center"><button onClick={() => setDraftInsertions(draftInsertions.filter(i => i.id !== item.id))} className="text-slate-600 hover:text-red-400"><Trash2 size={12} /></button></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : <div className="text-center py-6 border-2 border-dashed border-slate-700/50 rounded-xl text-[10px] text-slate-600">Aucune insertion</div>}
                        </div>
                    </div>

                    {/* TICKET DE RÉCAPITULATION */}
                    <div className="xl:col-span-1">
                        <div className="sticky top-28 space-y-6">
                            <div className="flex items-center gap-2 mb-2">
                                <div className="h-2 w-2 rounded-full bg-indigo-500 animate-pulse"></div>
                                <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">Récapitulatif</span>
                            </div>

                            <div className="bg-[#1E293B] rounded-2xl border border-slate-700 shadow-2xl overflow-hidden relative backdrop-blur-sm">
                                <div className="p-6 pb-4 bg-slate-800/80 border-b border-slate-700">
                                    <div className="flex justify-between items-start mb-4">
                                        <span className="px-2 py-1 rounded bg-indigo-500/10 text-indigo-400 text-[10px] font-bold uppercase border border-indigo-500/20">Brouillon</span>
                                        <span className="text-xs font-mono text-slate-500">{new Date().toLocaleDateString()}</span>
                                    </div>
                                    <h3 className="text-lg font-bold text-white leading-tight mb-1">{formData.nomPlan || "Nouvelle Campagne"}</h3>
                                    <p className="text-xs text-slate-400">{annonceurs.find(a => a.id === formData.annonceurId)?.nomAnnonceur || "Annonceur non sélectionné"}</p>
                                </div>

                                <div className="px-6 py-4 border-b border-slate-700 flex flex-wrap gap-2">
                                    {FIXED_OBJECTIVES.filter(o => formData.objectifs.includes(o)).map(o => (
                                        <span key={o} className="px-2 py-0.5 bg-slate-700 text-slate-300 text-[10px] font-bold uppercase rounded border border-slate-600">{o}</span>
                                    ))}
                                </div>

                                <div className="px-6 py-4 grid grid-cols-2 gap-4 border-b border-slate-700 bg-slate-800/30">
                                    {metrics.imps > 0 && <div><div className="text-[10px] text-slate-500 uppercase flex items-center gap-1 mb-1"><Eye size={10}/> Impressions</div><div className="text-sm font-mono text-white">{metrics.imps.toLocaleString()}</div></div>}
                                    {metrics.clicks > 0 && <div><div className="text-[10px] text-slate-500 uppercase flex items-center gap-1 mb-1"><MousePointerClick size={10}/> Clics</div><div className="text-sm font-mono text-white">{metrics.clicks.toLocaleString()}</div></div>}
                                    {metrics.views > 0 && <div><div className="text-[10px] text-slate-500 uppercase flex items-center gap-1 mb-1"><PlayCircle size={10}/> Vues</div><div className="text-sm font-mono text-white">{metrics.views.toLocaleString()}</div></div>}
                                    {metrics.leads > 0 && <div><div className="text-[10px] text-slate-500 uppercase flex items-center gap-1 mb-1"><Users size={10}/> Leads</div><div className="text-sm font-mono text-white">{metrics.leads.toLocaleString()}</div></div>}
                                    {metrics.imps === 0 && metrics.clicks === 0 && metrics.views === 0 && metrics.leads === 0 && (
                                        <div className="col-span-2 text-center text-[10px] text-slate-600 py-2 italic">Aucune donnée prévisionnelle</div>
                                    )}
                                </div>

                                <div className="p-6 bg-slate-900 border-t border-slate-800">
                                    <div className="flex justify-between items-end mb-4">
                                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Budget Global</span>
                                        <div className="text-right">
                                            <span className={`text-xl font-bold font-mono ${isOverBudget ? 'text-red-500' : 'text-white'}`}>
                                                {finalBudget.toLocaleString()} <span className="text-[10px] text-slate-500 font-normal">MAD</span>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    {isBudgetManual ? (
                                        <div className="flex justify-between items-center pt-3 border-t border-slate-800">
                                            <div className="flex flex-col"><span className="text-[9px] text-emerald-500 font-bold uppercase mb-0.5">Alloué</span><span className="text-xs font-mono text-emerald-400">{totalAllocated.toLocaleString()}</span></div>
                                            <div className="flex flex-col text-right"><span className={`text-[9px] font-bold uppercase mb-0.5 ${remainingBudget < 0 ? 'text-red-500' : 'text-slate-500'}`}>Reste</span><span className={`text-xs font-mono ${remainingBudget < 0 ? 'text-red-400' : 'text-slate-400'}`}>{remainingBudget.toLocaleString()}</span></div>
                                        </div>
                                    ) : (
                                        <div className="pt-2 border-t border-slate-800 text-center"><span className="text-[10px] text-indigo-400 italic">Calculé automatiquement (Somme)</span></div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    const renderSelectionScreen = () => (
        <div className="flex flex-col items-center justify-center min-h-full gap-12 p-8">
            <div className="text-center space-y-4 max-w-2xl">
                <div className="inline-flex items-center justify-center p-4 bg-indigo-500/10 rounded-full mb-2 ring-1 ring-indigo-500/30 shadow-[0_0_30px_rgba(99,102,241,0.2)]">
                    <Sparkles className="text-indigo-400" size={32} />
                </div>
                <h1 className="text-5xl font-bold text-white tracking-tight">Nouveau Plan Média</h1>
                <p className="text-slate-400 text-lg leading-relaxed">Plateforme de planification stratégique v11.0</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full max-w-6xl">
                <button onClick={() => setMode('manual')} className="group relative p-8 bg-[#1E293B] border border-slate-800 rounded-[2rem] hover:border-slate-600 transition-all text-left flex flex-col gap-6 hover:shadow-2xl">
                    <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center group-hover:bg-indigo-600 transition-colors duration-300">
                        <PenTool className="text-slate-400 group-hover:text-white" size={32} />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold text-slate-200 mb-2 group-hover:text-white">Media Planning Expert</h3>
                        <p className="text-xs text-slate-500 leading-relaxed">Interface complète : Multi-objectifs, ciblage audience, et allocation détaillée.</p>
                    </div>
                    <div className="mt-auto pt-4 flex items-center text-xs font-bold text-indigo-400 opacity-0 group-hover:opacity-100 transition-all">Configurer le Plan <ArrowRight size={16} className="ml-2" /></div>
                </button>
                <button onClick={() => setMode('ai')} className="group relative p-8 bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-indigo-500/20 rounded-[2rem] hover:border-indigo-500 transition-all text-left flex flex-col gap-6">
                    <div className="absolute top-0 right-0 p-8 z-10"><span className="bg-indigo-500/10 text-indigo-400 text-[10px] font-bold px-3 py-1 rounded-full border border-indigo-500/20 uppercase tracking-wider flex items-center gap-1"><Sparkles size={10} /> Beta</span></div>
                    <div className="w-16 h-16 rounded-2xl bg-indigo-900/20 flex items-center justify-center group-hover:bg-indigo-500 transition-colors duration-300"><Wand2 className="text-indigo-400 group-hover:text-white" size={32} /></div>
                    <div><h3 className="text-xl font-bold text-white mb-2">Assistant IA</h3><p className="text-xs text-slate-400 leading-relaxed">Générez un plan structuré à partir d'un brief textuel.</p></div>
                    <div className="mt-auto pt-4 flex items-center text-xs font-bold text-indigo-400 opacity-0 group-hover:opacity-100 transition-all">Lancer l'assistant <ArrowRight size={16} className="ml-2" /></div>
                </button>
                <button onClick={() => setMode('config')} className="group relative p-8 bg-[#1E293B] border border-slate-800 rounded-[2rem] hover:border-slate-600 transition-all text-left flex flex-col gap-6 hover:shadow-2xl">
                    <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center group-hover:bg-emerald-600 transition-colors duration-300">
                        <Settings className="text-slate-400 group-hover:text-white" size={32} />
                    </div>
                    <div>
                        <h3 className="text-xl font-bold text-slate-200 mb-2 group-hover:text-white">Admin Data</h3>
                        <p className="text-xs text-slate-500 leading-relaxed">Gérez les canaux, formats et specs techniques du système.</p>
                    </div>
                    <div className="mt-auto pt-4 flex items-center text-xs font-bold text-emerald-400 opacity-0 group-hover:opacity-100 transition-all">Gérer le système <ArrowRight size={16} className="ml-2" /></div>
                </button>
            </div>
        </div>
    );

    const renderAIAssistant = () => (
        <div className="h-full flex flex-col p-8 items-center justify-center">
             <div className="bg-[#1E293B] border border-slate-800 rounded-3xl p-10 shadow-2xl relative overflow-hidden max-w-3xl w-full">
                <h3 className="text-xl font-bold text-white mb-6">Brief Créatif Intelligent</h3>
                <textarea className="w-full h-40 bg-[#0F172A] border border-slate-700 rounded-xl p-5 text-slate-200 focus:border-indigo-500 outline-none resize-none text-base mb-6" placeholder="Décrivez votre besoin..." value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)} />
                <div className="flex justify-center gap-4">
                    <button onClick={() => setMode('selection')} className="text-slate-500 hover:text-white">Annuler</button>
                    <button disabled={true} className="px-10 py-4 rounded-xl text-sm font-bold bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-3"><Wand2/> Générer</button>
                </div>
             </div>
        </div>
    );

    // --- MAIN RENDER ---
    return (
        <StudioLayout
            leftContent={
                <div className="h-full flex flex-col bg-[#020617] border-r border-slate-800 w-full p-4">
                    <div className="mb-4 font-bold text-slate-400 uppercase text-xs tracking-widest px-2">Navigation</div>
                    <a href='/' className="w-full text-left px-3 py-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-sm transition-colors flex items-center gap-2 mb-1"><Home size={16} /> Accueil</a>
                    <button onClick={() => setMode('selection')} className="w-full text-left px-3 py-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-sm transition-colors flex items-center gap-2"><Plus size={16} /> Nouveau</button>
                    <button onClick={() => setMode('config')} className="w-full text-left px-3 py-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-sm transition-colors flex items-center gap-2 mt-4 border-t border-slate-800 pt-4"><Settings size={16} /> Admin Data</button>
                    <div className="mt-auto p-4 bg-slate-900 rounded-xl border border-slate-800">
                        <div className="flex items-center gap-2 mb-2">
                            <div className={`w-2 h-2 rounded-full ${dataStatus === 'empty' ? 'bg-amber-500' : 'bg-emerald-500'} animate-pulse`}></div>
                            <span className={`text-[10px] font-bold uppercase ${dataStatus === 'empty' ? 'text-amber-500' : 'text-emerald-500'}`}>{dataStatus === 'empty' ? 'Base Vide' : 'Connecté'}</span>
                        </div>
                        <div className="text-[10px] text-slate-500">Données chargées : {canaux.length} Canaux, {formats.length} Formats.</div>
                    </div>
                </div>
            } 
            rightContent={
                <div className="h-full bg-[#0F172A] relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-[#0F172A] to-[#0F172A] pointer-events-none"></div>
                    <div className="relative z-10 h-full overflow-hidden">
                        {mode === 'selection' && renderSelectionScreen()}
                        {mode === 'manual' && renderManualForm()}
                        {mode === 'ai' && renderAIAssistant()}
                        {mode === 'config' && renderConfigScreen()}
                    </div>
                </div>
            }
            bottomContent={
                <div className="h-9 bg-[#020617] border-t border-slate-800 flex items-center justify-between px-6 text-[10px] text-slate-500 flex-shrink-0 z-50 select-none">
                    <div className="flex items-center gap-4"><span className="font-bold text-slate-400 tracking-wider">MODULE CRÉATION v11.4 (SYNCHRO FIX)</span></div>
                    <div className="flex items-center gap-2">
                        {mode === 'manual' && <span className="text-indigo-500 font-bold">MODE EXPERT</span>}
                        {mode === 'config' && <span className="text-emerald-500 font-bold">MODE ADMIN</span>}
                        {mode === 'ai' && <span className="text-purple-500 font-bold">MODE INTELLIGENT</span>}
                    </div>
                </div>
            }
        />
    );
}