import type { Metadata } from "next";
import "./globals.css"; // <--- C'est ICI que la magie opère. Sans ça, pas de couleurs.

export const metadata: Metadata = {
  title: "Agence Studio",
  description: "Sandbox de génération de rapports",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}