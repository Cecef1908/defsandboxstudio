'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Layout, BarChart3, ArrowRight, Database, ShieldCheck, Zap, 
  Settings, Command, Plus, Clock, TrendingUp // Ajout de TrendingUp pour la nouvelle carte
} from 'lucide-react';

// --- SYSTEM CLOCK ---
function SystemClock() {
    const [time, setTime] = useState<Date | null>(null);
    useEffect(() => {
        setTime(new Date());
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    if (!time) return <div className="w-16 h-4 bg-slate-800/50 rounded animate-pulse"></div>;

    return (
        <div className="font-mono text-[10px] text-indigo-400 flex items-center gap-2 bg-[#0F172A] px-2 py-1 rounded border border-slate-800 shadow-sm">
            <Clock size={10} />
            {time.toLocaleTimeString('fr-FR')}
        </div>
    );
}

export default function Home() {
  return (
    <div className="min-h-screen bg-[#020617] text-slate-300 font-sans selection:bg-indigo-500/30 flex flex-col">
      
      {/* --- HEADER --- */}
      <header className="px-8 py-6 border-b border-slate-800/50 flex justify-between items-center bg-[#0F172A]/50 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          {/* LOGO 5BOX */}
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-violet-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-900/20 text-white font-bold text-sm ring-1 ring-white/10">
            5B
          </div>
          <div>
            <h1 className="text-white font-bold text-lg leading-none tracking-tight">5BOX OS</h1>
            <p className="text-[10px] text-slate-500 font-medium uppercase tracking-widest mt-1">Enterprise Workspace</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
           {/* HORLOGE AJOUTÉE ICI */}
           <div className="hidden md:flex items-center gap-4 mr-4 border-r border-slate-800 pr-4">
              <SystemClock />
           </div>

           <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-900 rounded-lg border border-slate-800 text-xs font-mono text-slate-500">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              System Online
           </div>
           <button className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 transition-colors">
              <Settings size={14} />
           </button>
           <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold text-xs shadow-lg shadow-indigo-500/20 cursor-pointer hover:scale-105 transition-transform">
              AD
           </div>
        </div>
      </header>

      {/* --- MAIN CONTENT --- */}
      <main className="flex-1 flex flex-col items-center justify-center p-8 relative overflow-hidden">
        
        {/* Background Gradients */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-6xl w-full z-10">
          
          <div className="text-center mb-16 space-y-4">
             <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/50 border border-slate-700 text-[10px] uppercase tracking-widest font-bold text-indigo-400 mb-2">
                <Command size={10} /> v2.0 Beta
             </div>
             <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">
               Bienvenue dans votre <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-violet-400">Studio</span>
             </h2>
             <p className="text-slate-400 text-lg max-w-xl mx-auto">
               Gérez vos campagnes, créez de nouveaux plans et analysez vos performances.
             </p>
          </div>

          {/* APP GRID - NOUVELLE CARTE EN PLUS */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mx-auto">
            
            {/* CARD 1 : CRÉATION */}
            <Link href="/studio/nouveau-plan" className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-3xl blur opacity-0 group-hover:opacity-20 transition-opacity duration-500" />
              <div className="relative h-full bg-[#1E293B] border border-slate-700 p-8 rounded-3xl hover:border-emerald-500/50 transition-all duration-300 flex flex-col justify-between group-hover:-translate-y-1 shadow-2xl">
                 <div>
                    <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-emerald-500 group-hover:text-white text-emerald-400 transition-colors duration-300">
                       <Plus size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-emerald-300 transition-colors">Nouveau Plan</h3>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      Créez un plan média à partir de zéro ou utilisez l'assistant IA pour générer une structure.
                    </p>
                 </div>
                 <div className="mt-8 flex items-center text-xs font-bold text-emerald-400 group-hover:text-white transition-colors uppercase tracking-wider">
                    Démarrer <ArrowRight size={14} className="ml-2 group-hover:translate-x-1 transition-transform" />
                 </div>
              </div>
            </Link>

            {/* CARD 2 : PLAN MEDIA (GESTION) */}
            <Link href="/studio/plan-media" className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-blue-600 rounded-3xl blur opacity-0 group-hover:opacity-20 transition-opacity duration-500" />
              <div className="relative h-full bg-[#1E293B] border border-slate-700 p-8 rounded-3xl hover:border-indigo-500/50 transition-all duration-300 flex flex-col justify-between group-hover:-translate-y-1 shadow-2xl">
                 <div>
                    <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-500 group-hover:text-white text-indigo-400 transition-colors duration-300">
                       <Layout size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-300 transition-colors">Mes Plans</h3>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      Accédez à vos plans en cours, modifiez les budgets et suivez l'avancement des campagnes.
                    </p>
                 </div>
                 <div className="mt-8 flex items-center text-xs font-bold text-indigo-400 group-hover:text-white transition-colors uppercase tracking-wider">
                    Gérer <ArrowRight size={14} className="ml-2 group-hover:translate-x-1 transition-transform" />
                 </div>
              </div>
            </Link>

            {/* CARD 3 : PORTEFEUILLE MEDIA (NOUVELLE CARTE) */}
            <Link href="/studio/portefeuille" className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-violet-500 to-purple-600 rounded-3xl blur opacity-0 group-hover:opacity-20 transition-opacity duration-500" />
              <div className="relative h-full bg-[#1E293B] border border-slate-700 p-8 rounded-3xl hover:border-violet-500/50 transition-all duration-300 flex flex-col justify-between group-hover:-translate-y-1 shadow-2xl">
                 <div>
                    <div className="w-12 h-12 bg-violet-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-violet-500 group-hover:text-white text-violet-400 transition-colors duration-300">
                       <TrendingUp size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-violet-300 transition-colors">Portefeuille Média</h3>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      Vue stratégique consolidée : budgets, canaux et performances agrégées de l'agence.
                    </p>
                 </div>
                 <div className="mt-8 flex items-center text-xs font-bold text-violet-400 group-hover:text-white transition-colors uppercase tracking-wider">
                    Analyser <ArrowRight size={14} className="ml-2 group-hover:translate-x-1 transition-transform" />
                 </div>
              </div>
            </Link>

            {/* CARD 4 : BILAN / REPORTING (Décalée) */}
            <Link href="/studio/bilan" className="group relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-500 to-amber-600 rounded-3xl blur opacity-0 group-hover:opacity-20 transition-opacity duration-500" />
              <div className="relative h-full bg-[#1E293B] border border-slate-700 p-8 rounded-3xl hover:border-yellow-500/50 transition-all duration-300 flex flex-col justify-between group-hover:-translate-y-1 shadow-2xl">
                 <div>
                    <div className="w-12 h-12 bg-yellow-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-yellow-500 group-hover:text-black text-yellow-500 transition-colors duration-300">
                       <BarChart3 size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-yellow-300 transition-colors">Bilans</h3>
                    <p className="text-sm text-slate-400 leading-relaxed">
                      Consultez les rapports de performance consolidés et générez des bilans annuels.
                    </p>
                 </div>
                 <div className="mt-8 flex items-center text-xs font-bold text-yellow-500 group-hover:text-white transition-colors uppercase tracking-wider">
                    Détails <ArrowRight size={14} className="ml-2 group-hover:translate-x-1 transition-transform" />
                 </div>
              </div>
            </Link>

          </div>

          {/* QUICK LINKS / FOOTER */}
          <div className="mt-20 border-t border-slate-800 pt-8 grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left opacity-60 hover:opacity-100 transition-opacity">
             <div>
                <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Ressources</h4>
                <ul className="space-y-2 text-xs text-slate-400">
                   <li className="hover:text-white cursor-pointer transition-colors">Documentation</li>
                   <li className="hover:text-white cursor-pointer transition-colors">Support</li>
                </ul>
             </div>
             <div>
                <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-4">Système</h4>
                <ul className="space-y-2 text-xs text-slate-400">
                   <li className="flex items-center gap-2 justify-center md:justify-start"><div className="w-1 h-1 rounded-full bg-emerald-500"></div> API Online</li>
                   <li className="flex items-center gap-2 justify-center md:justify-start"><div className="w-1 h-1 rounded-full bg-blue-500"></div> Database Connected</li>
                </ul>
             </div>
             <div className="text-center md:text-right">
                <div className="text-xl font-bold text-white tracking-tight">5BOX</div>
                <div className="text-[10px] text-slate-500 mt-1">© 2025 Tous droits réservés.</div>
             </div>
          </div>

        </div>
      </main>
    </div>
  );
}