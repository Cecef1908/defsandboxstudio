import React from 'react';

interface StudioLayoutProps {
  leftContent: React.ReactNode;   // Sidebar
  rightContent: React.ReactNode;  // Dashboard
  bottomContent?: React.ReactNode; // Footer (Optionnel)
  children?: React.ReactNode;     // Éléments cachés
}

export default function StudioLayout({
  leftContent,
  rightContent,
  bottomContent,
  children
}: StudioLayoutProps) {
  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#020617] text-slate-200">
      {/* GAUCHE: Sidebar */}
      <aside className="w-80 flex-shrink-0 flex flex-col border-r border-slate-800 bg-[#020617] h-full z-20">
        {leftContent}
      </aside>

      {/* DROITE: Zone Principale */}
      <main className="flex flex-1 flex-col h-full min-w-0 bg-[#0F172A] relative z-10">
        
        {/* HAUT: Zone de Rendu (Dashboard) */}
        <div className="flex-1 relative overflow-hidden">
          {rightContent}
        </div>

        {/* BAS: Footer (Hauteur automatique selon le contenu, pas de fond blanc forcé) */}
        {bottomContent && (
          <div className="flex-shrink-0 w-full z-30">
            {bottomContent}
          </div>
        )}
      </main>

      {/* Éléments cachés (Textarea d'état) */}
      <div className="hidden" style={{ display: 'none' }}>
        {children}
      </div>
    </div>
  );
}